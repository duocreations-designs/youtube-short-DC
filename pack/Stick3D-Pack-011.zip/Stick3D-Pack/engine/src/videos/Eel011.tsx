// Odd Truth Toons 011 "Eel" (What If, 1886 Amsterdam). 720x1280 comp, rendered at scale 2 -> 1440x2560 master.
// 8 stages (crossfade/flash/whip/rewind only between stages), 31 shots (hard cuts inside a stage), 17 top-band pop texts, word captions.
import React from "react";
import { AbsoluteFill, useCurrentFrame, Easing, Audio, staticFile, delayRender, continueRender, interpolate } from "remotion";
import "@fontsource/archivo-black/400.css";
import { Box, Cyl, Ball, CanvasPlane, Surface, BrickWall } from "../style/toon";
import { Person, Lights, Grade, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Shaft, Dust } from "../style/props";
import { Cam, Key, camAt, FaceGroup, hand, Stars } from "../style/extra";
import { CanalHouse, Rowboat, Eel, Rope, sagPts, Knife, Rifle, Barrel, Crate, Bollard, Cart, Tree, OldLamp, Splash, Smoke, Flash, Laundry } from "../style/oldtown";
import { FPS, WALK, Ctx, Scene, cop, henk, poler, soldier, folk, toWorld, up1, Q, TOPL, TOPR, CLEAT, SAG, EEL0, BR_Z, REP_Q, HOUSE_COLS, Water, Sky, CanalWorld, crowdPose, jump, boatY, StreetSet, PL } from "./eel/world";
import words from "../../public/words.json";
import SCRIPT from "../../public/script.json";

export const DUR011 = 1710; // 57.0 s
const G = 9.8;

/* ---------- shots: hard cuts inside a stage ---------- */
type Shot = { t0: number; keys: Key[]; impacts?: [number, number][]; fovKick?: number[]; quake?: number };
const active = (t: number, shots: Shot[]) => { let s = shots[0]; for (const x of shots) if (t >= x.t0) s = x; return s; };
const Shots: React.FC<{ t: number; shots: Shot[] }> = ({ t, shots }) => { const s = active(t, shots); return <Cam t={t} keys={s.keys} impacts={s.impacts} fovKick={s.fovKick} quake={s.quake} />; };
const camPos = (t: number, shots: Shot[]) => camAt(t, active(t, shots).keys).pos as V3;
const K = (t: number, pos: V3, look: V3, fov = 56): Key => ({ t, pos, look, fov });

/* =================== STAGE 1 canal, Sunday afternoon (0 – 26.10) =================== */
const OFF0: V3 = [-7.8, Q, 6.6], OFF1: V3 = [-4.85, Q, 0.85], OW0 = 20.6, OW1 = 22.4;
const CUT = 23.5, RUN = 24.69, SPL = 25.32, KN_UP: [number, number] = [0.3, 0.62], KN_CUT: [number, number] = [0.27, 0.43];
const J1 = 13.5, J2 = 16.55;
const S1: Shot[] = [
  { t0: 0, keys: [K(0, [0.7, 4.6, 3.6], [0, 4.55, 0], 50), K(1.8, [0.45, 4.55, 2.9], [0, 4.5, 0], 46)] },
  { t0: 1.75, keys: [K(1.75, [0.5, 3.8, -1.8], [0, 5.1, -11], 52), K(3.9, [0.9, 4.4, 0.8], [0, 5.0, -11], 56)] },
  { t0: 3.86, keys: [K(3.86, [-2.6, 4.8, 3.6], [-4.0, 4.95, 0.2], 52), K(6.3, [-3.2, 4.85, 3.2], [-4.0, 4.95, 0.2], 50)] },
  { t0: 6.23, keys: [K(6.23, [3.0, 5.6, 16], [0, 4.2, -8], 60), K(7.2, [2.2, 8.4, 13.5], [0, 4.0, -8], 60), K(8.7, [1.6, 9.6, 12.2], [0, 3.8, -8], 60)] },
  { t0: 8.68, keys: [K(8.68, [1.4, 4.65, 3.4], [0, 4.75, 0], 48), K(10.95, [1.2, 4.6, 3.0], [0, 4.75, 0], 46), K(11.3, [2.4, 4.8, 8.4], [0, 4.9, -2], 58), K(12.8, [2.8, 5.1, 10.2], [0, 5.0, -2], 58)] },
  { t0: 12.73, keys: [K(12.73, [2.9, 1.45, 6.0], [0, 4.7, -0.5], 58), K(15.3, [2.6, 1.5, 5.0], [0.1, 5.0, 0.5], 58)] },
  { t0: 15.2, keys: [K(15.2, [2.4, 3.2, 6.6], [-0.3, 4.9, -3], 56), K(17.6, [1.8, 3.3, 5.0], [-0.3, 4.8, -3], 54)], fovKick: [15.94] },
  { t0: 17.54, keys: [K(17.54, [-3.1, 3.3, -5.2], [-4.7, 3.25, -8.95], 50), K(20.6, [-3.5, 3.3, -6.0], [-4.7, 3.25, -8.95], 48)], fovKick: [19.93] },
  { t0: 20.56, keys: [K(20.56, [-4.6, 3.5, 11.2], [-7.2, 3.7, 4.4], 54), K(22.5, [-2.9, 3.3, 6.9], [-4.8, 3.6, 1.2], 50)] },
  { t0: 22.49, keys: [K(22.49, [-2.5, 3.4, 4.3], [-4.1, 3.35, 0.8], 56), K(23.55, [-2.7, 3.4, 4.0], [-4.1, 3.3, 0.8], 54)] },
  { t0: 23.5, keys: [K(23.5, [-2.4, 3.0, 3.4], [-4.0, 2.75, 0.4], 46), K(24.3, [-2.5, 3.0, 3.3], [-4.0, 2.9, 0.3], 46)] },
  { t0: 24.25, keys: [K(24.25, [-0.6, 6.4, 6.6], [0.1, 1.2, -0.4], 56), K(26.3, [0.2, 7.6, 6.4], [0.3, 0.5, -1.0], 58)], impacts: [[SPL, 0.012]] },
];
const CUTP: V3 = toWorld(OFF1, hand(3.4, KN_CUT, 0, false, 0.08), camAt(CUT, S1[10].keys).pos as V3);
const offPos = (t: number): V3 => { const k = seg(t, OW0, OW1, Easing.inOut(Easing.sin)); return [lerp(OFF0[0], OFF1[0], k), Q, lerp(OFF0[2], OFF1[2], k)]; };
const knifeTgt = (t: number): [number, number] => {
  if (t < 22.5) return [0.12, 0.42];
  if (t < 22.95) { const k = seg(t, 22.5, 22.95, Easing.inOut(Easing.sin)); return [lerp(0.12, KN_UP[0], k), lerp(0.42, KN_UP[1], k)]; }
  if (t < 23.36) return KN_UP;
  if (t < CUT) { const k = seg(t, 23.36, CUT, Easing.in(Easing.quad)); return [lerp(KN_UP[0], KN_CUT[0], k), lerp(KN_UP[1], KN_CUT[1], k)]; }
  const k = seg(t, CUT, CUT + 0.12); return [lerp(KN_CUT[0], 0.14, k), lerp(KN_CUT[1], 0.36, k)];
};
const GE = 2 * (EEL0[1] - 1.855) / ((SPL - RUN) * (SPL - RUN)); // eel gravity: the tail still hits the water at SPL from the higher start
const eelFall = (t: number) => {
  if (t < CUT) return { p: EEL0, sag: SAG };
  if (t < RUN) { const k = seg(t, CUT, RUN, Easing.in(Easing.quad)); return { p: [0.15 * k, EEL0[1] - 0.6 * k, 0] as V3, sag: SAG + 0.6 * k }; }
  const d = t - RUN; return { p: [0.15 + 0.5 * d, EEL0[1] - 0.6 - 0.5 * GE * d * d, 0.1 * d] as V3, sag: SAG + 0.6 };
};
const swingX = (t: number) => -0.55 * Math.sin(t * 3.0) * Math.exp(-t * 0.45);
const Stage1 = ({ t, f }: Ctx) => {
  const P = offPos(t), moving = t > OW0 && t < OW1, dist = Math.hypot(P[0] - OFF0[0], P[2] - OFF0[2]);
  const kt = knifeTgt(t), knifeOut = t > 22.55;
  const ef = eelFall(t), endUp = seg(t, CUT, RUN, Easing.in(Easing.quad));
  const runEnd: V3 = [lerp(CUTP[0], TOPL[0], endUp), lerp(CUTP[1], TOPL[1], endUp), lerp(CUTP[2], TOPL[2], endUp)];
  const lowerEnd: V3 = [CLEAT[0] + 0.05 * Math.sin((t - CUT) * 9) * Math.exp(-(t - CUT) * 3), lerp(CUTP[1], CLEAT[1] - 0.55, seg(t, CUT, CUT + 0.35, Easing.out(Easing.quad))), CLEAT[2] + 0.06];
  const free = t >= RUN, under = ef.p[1] < -0.4;
  // boat 1 (Henk): jump, grab, slip, fall back into the boat
  const b1z = (t - 13.85) * 1.6, j1 = jump(t, J1, 0.9, 2.0), hold1 = t > 13.78 && t < 14.2;
  const dip1 = t > J1 + 0.9 ? 0.12 * Math.exp(-(t - J1 - 0.9) * 5) * Math.cos((t - J1 - 0.9) * 14) : 0, by1 = boatY(t, dip1);
  const H1: V3 = [0.15, by1 + 0.72 + j1.y, b1z + 0.55], fell1 = t > J1 + 0.9 && t < 15.6;
  // boat 2: jumps, misses, splashes into the canal
  const b2z = (t - 16.9) * 1.5, by2 = boatY(t + 1), j2 = jump(t, J2, 0.55, 1.9), miss = t > J2 + 0.3;
  const h0 = by2 + 0.72 + Math.sin(clamp(0.3 / 0.55) * Math.PI) * 1.9, T2 = 0.69, G2 = 2 * (h0 + 1.2 * T2) / (T2 * T2); // same splash time as v1 from the higher jump
  const fallD = Math.max(0, t - (J2 + 0.3)), H2: V3 = miss ? [-0.4 - 0.9 * fallD, Math.max(-1.5, h0 + 1.2 * fallD - 0.5 * G2 * fallD * fallD), b2z + 0.5] : [-0.4, by2 + 0.72 + j2.y, b2z + 0.5];
  const spl2 = J2 + 0.3 + T2;
  const holdEel = hold1 || (t > J2 + 0.15 && t < J2 + 0.3);
  const crowdMode = t < 15.9 ? "idle" : t < 18.0 ? "cheer" : t < CUT + 0.1 ? "idle" : t < 25.6 ? "shock" : "angry";
  return (<>
    <Shots t={t} shots={S1} />
    <CanalWorld t={t} f={f} sky={["#3a86e0", "#ffcf8a"]} water={["#1f7484", "rgba(225,252,255,1)"]} sun={[-26, 18, -66]} crowd={crowdMode as "idle"} crowdT={CUT + 0.1} skipLeftNear />
    {!free ? <Rope pts={sagPts(TOPL, TOPR, holdEel ? ef.sag + 0.25 : ef.sag)} /> : !under ? <Rope pts={sagPts(TOPR, up1(ef.p, 0.02), 0.25, 8)} /> : <Rope pts={sagPts(TOPR, [0.9, 0.0, 0.2], 0.4, 8)} />}
    {t < CUT ? <Rope pts={[TOPL, CUTP, CLEAT]} /> : <><Rope pts={[CLEAT, lowerEnd]} />{!free ? <Rope pts={[TOPL, runEnd]} /> : null}</>}
    {!under ? <group position={holdEel ? up1(ef.p, -0.25) : ef.p} rotation={[t < 8 ? swingX(t) : 0, 0, 0]}><Eel p={[0, 0, 0]} t={t} wig={holdEel ? 2.4 : t > CUT ? 2.2 : 1.2} s={holdEel ? 1.18 : 1} eyeShock={t > CUT} /></group> : null}
    <Glow p={up1(EEL0, -0.55)} r={1.0} color="rgba(255,255,235,1)" o={0.15 + 0.6 * seg(t, 9.6, 9.8) * (1 - seg(t, 10.0, 10.6))} />
    <Splash p={[0.8, 0, 0.1]} t={t} t0={SPL} />
    {/* boats */}
    {t > 11 && t < 15.2 ? <><Rowboat p={[0.3, by1, b1z]} roll={fell1 ? 0.05 * Math.sin((t - J1 - 0.9) * 12) * Math.exp(-(t - J1 - 0.9) * 3) : 0} />
      <Person p={H1} sy={by1 + 0.72} h={3.0} look={henk} f={f} shadow={false} pose={{ mood: t < J1 ? "grin" : t < 14.2 ? "laugh" : t < 15.2 ? "shock" : "grin", squash: j1.sq, air: j1.inAir ? 1 : 0, arms: t < J1 - 0.2 ? "hold" : "up", armK: seg(t, J1 - 0.3, J1), armR: hold1 ? [0.06, 0.98] : undefined, armL: hold1 ? [-0.06, 0.98] : undefined, armRK: 1, armLK: 1, tilt: fell1 ? -0.22 * Math.exp(-(t - J1 - 0.9) * 2) : 0, sweat: fell1 ? 1 : 0 }} />
      {(() => { const PP: V3 = [0.45, by1 + 0.72, b1z - 1.25], push = Math.sin(t * 2.4) * 0.5 + 0.5, tg: [number, number] = [0.22, lerp(0.55, 0.7, push)];
        return <><Person p={PP} sy={by1 + 0.72} h={3.0} look={poler} f={f + 11} shadow={false} pose={{ mood: t > 14.2 && t < 15.6 ? "laugh" : "smile", armR: tg, armL: [-0.05, lerp(0.5, 0.62, push)], armRK: 1, armLK: 1, lookX: 0.3 }} />
          <FaceGroup p={PP}><group position={hand(3.0, tg, 0, false, 0.05)} rotation={[0.25, 0, -0.35]}><Cyl p={[0, -1.0, 0]} rt={0.04} h={5.0} color="#8a5a32" line={1} /></group></FaceGroup></>; })()}</> : null}
    {t > 14.8 && t < 18.2 ? <><Rowboat p={[-0.3, by2, b2z]} color="#3a6a3a" />{H2[1] > -1.2 ? <Person p={H2} sy={by2 + 0.72} h={3.0} look={folk[5]} f={f + 3} shadow={false} pose={{ mood: miss ? "shock" : "grin", squash: j2.sq, air: 1, arms: "up", armK: 1, tilt: miss ? -0.6 * clamp(fallD * 2) : 0 }} /> : null}<Splash p={[-0.9, 0, b2z + 0.5]} t={t} t0={spl2} /></> : null}
    {t < 11 ? <Rowboat p={[0.3, boatY(t), lerp(-22, -10, t / 11)]} /> : null}
    {/* bystanders step aside for the officer */}
    {[[-6.9, 4.6], [-5.9, 2.5]].map(([x, z], i) => { const push = seg(t, 21.0 + i * 0.45, 21.5 + i * 0.45, Easing.out(Easing.back(1.6))); return <Person key={"by" + i} p={[x - 1.3 * push, Q, z + (i ? -0.4 : 0.5) * push]} h={3.0} look={folk[(i + 4) % 8]} f={f + i * 13} pose={{ mood: t > CUT ? "shock" : push > 0.2 ? "worry" : "smile", tilt: -0.12 * Math.sin(push * Math.PI), arms: t > CUT + 0.1 ? "head" : "down", armK: seg(t, CUT + 0.1, CUT + 0.3), lookX: 1 }} />; })}
    {t > 20.2 ? <><Person p={P} h={3.4} look={cop} f={f} pose={{ mood: t < OW1 ? "angry" : t < CUT ? "deadpan" : "shock", walk: moving ? dist * WALK : undefined, speed: moving ? 0.9 : 0, armR: knifeOut ? kt : undefined, armRK: knifeOut ? 1 : 0, arms: "down", lookX: t > 24 ? 0.8 : 0.4, squash: t > CUT && t < CUT + 0.25 ? -0.05 : 0, nerv: t > 24.4 ? 0.3 : 0, sweat: t > 25 ? 1 : 0 }} />
      {knifeOut ? <FaceGroup p={P}><Knife p={hand(3.4, kt, 0, false, 0.12)} rot={[0, 0, t < 23.36 ? -0.2 : -0.9]} s={1.25} glint={0.9 * seg(t, 22.9, 23.0) * (1 - seg(t, 23.1, 23.4))} /></FaceGroup> : null}</> : null}
    <Glow p={CUTP} r={0.7} color="rgba(255,255,255,1)" o={t > CUT && t < CUT + 0.15 ? 0.9 : 0} />
    <Shaft p={[-2, 6, -4]} s={[4, 12]} rot={[0, 0, 0.35]} color="255,220,150" o={0.16} />
  </>);
};

/* =================== STAGE 2 riot street, Sunday evening (26.10 – 31.41) =================== */
const S2: Shot[] = [
  { t0: 26.1, keys: [K(26.1, [0.6, 1.5, 9.6], [0, 4.0, -4], 60), K(28.5, [0.5, 1.45, 8.4], [0, 4.0, -4], 58)], impacts: [[27.49, 0.05]], fovKick: [27.49] },
  { t0: 28.42, keys: [K(28.42, [2.4, 2.6, 6.0], [-3.4, 8.4, -2.4], 58), K(30.2, [2.2, 2.6, 5.6], [-2.6, 8.0, -2.4], 58)] },
  { t0: 30.18, keys: [K(30.18, [1.4, 2.7, 4.6], [0, 2.7, -3.0], 52), K(31.6, [0.8, 2.8, 3.6], [0, 2.6, -6.0], 54)], impacts: [[30.3, 0.015]] },
];
const roofers: { p: V3; t0: number; tgt: V3 }[] = [
  { p: [-4.5, 7.1, -1.6], t0: 28.5, tgt: [-0.8, 0.1, -2.6] }, { p: [-4.5, 7.7, -5.4], t0: 28.8, tgt: [0.9, 0.1, -3.6] }, { p: [4.5, 8.3, -2.6], t0: 29.1, tgt: [-0.3, 0.1, -1.6] },
  { p: [-4.5, 7.7, 2.4], t0: 29.4, tgt: [0.4, 0.1, -2.2] }, { p: [4.5, 7.5, 1.2], t0: 29.7, tgt: [1.2, 0.1, -3.0] },
];
const FLY = 0.62;
const Stage2 = ({ t, f }: Ctx) => {
  const boom = seg(t, 27.45, 27.6, Easing.out(Easing.back(2)));
  return (<>
    <Shots t={t} shots={S2} />
    <StreetSet t={t} f={f} sky={["#4a1a4a", "#ff7a3a"]} lit={0.55} lamps={1} />
    <Glow p={[0, 4, -30]} r={14} color="rgba(255,120,60,1)" o={0.5} />
    <Glow p={[0, 2.5, -3]} r={5 * boom} color="rgba(255,200,120,1)" o={0.6 * (1 - seg(t, 27.6, 28.2))} />
    {roofers.map((r, i) => { const wind = seg(t, r.t0 - 0.35, r.t0, Easing.inOut(Easing.sin)), thr = seg(t, r.t0, r.t0 + 0.12); const tg: [number, number] = t < r.t0 ? [0.2, lerp(0.6, 0.92, wind)] : [lerp(0.2, 0.34, thr), lerp(0.92, 0.5, thr)];
      const flip = r.p[0] > 0, h = 2.6; const rel = toWorld(r.p, hand(h, [0.2, 0.92], 0, flip, 0.1), camPos(r.t0, S2));
      const d = t - r.t0, u = clamp(d / FLY), vy = (r.tgt[1] - rel[1] + 0.5 * G * FLY * FLY) / FLY; const sp: V3 = d < 0 ? rel : d < FLY ? [lerp(rel[0], r.tgt[0], u), rel[1] + vy * d - 0.5 * G * d * d, lerp(rel[2], r.tgt[2], u)] : [r.tgt[0] + 0.5 * (1 - Math.exp(-(d - FLY) * 5)) * (i % 2 ? 1 : -1), 0.14, r.tgt[2] + 0.3 * (1 - Math.exp(-(d - FLY) * 5))];
      return <React.Fragment key={i}><Person p={r.p} h={h} look={folk[(i + 1) % 8]} f={f + i * 9} shadow={false} pose={{ mood: "angry", armR: tg, armRK: t > r.t0 - 0.4 ? 1 : 0, arms: "up", armK: 0.5, flip, lookX: flip ? -1 : 1 }} />
        {t > r.t0 - 0.4 ? (i % 2 ? <Box p={sp} s={[0.34, 0.06, 0.24]} rot={[d * 9, d * 6, 0]} color="#b4532e" line={2} /> : <Ball p={sp} r={0.16} color="#8a8a92" />) : null}
        {d > FLY && d < FLY + 0.4 ? <Glow p={[r.tgt[0], 0.3, r.tgt[2]]} r={0.9} color="rgba(220,200,180,1)" o={0.8 * (1 - (d - FLY) / 0.4)} /> : null}</React.Fragment>; })}
    {[[-1.0, 0, -3.0], [0.6, 0, -2.4], [1.6, 0, -3.6]].map((c, i) => { const rk = Math.max(0, t - (30.35 + i * 0.12)), dz = rk > 0 ? -(rk * 3.4 + 0.5 * rk * rk) : 0; const P: V3 = [c[0] + (i - 1) * 0.3 * Math.min(1, rk), 0, c[2] + dz];
      const duck = t > 28.9 && t < 30.3 ? Math.abs(Math.sin((t - 28.9 + i * 0.3) * 4)) : 0;
      return <Person key={"cop" + i} p={P} h={3.3} look={cop} f={f + i * 5} pose={{ mood: t < 28.5 ? "angry" : "shock", arms: t > 28.5 ? "head" : "down", armK: seg(t, 28.5, 28.7), squash: -0.12 * duck, hunch: 0.5 * duck, walk: rk > 0 ? -dz * WALK : undefined, speed: rk > 0 ? 1 : 0, nerv: t > 28.6 ? 0.6 : 0, sweat: t > 28.8 ? 1 : 0, lookX: i - 1 }} />; })}
    {Array.from({ length: 7 }, (_, i) => { const rk = Math.max(0, t - (30.6 + i * 0.1)), z0 = 3.2 + (i % 3) * 1.3, x0 = -3.0 + i * 1.0; const dz = rk > 0 ? -(rk * 3.6 + 0.5 * rk * rk) : 0;
      return <Person key={"m" + i} p={[x0, 0, z0 + dz]} h={3.1} look={folk[(i + 3) % 8]} f={f + i * 7} pose={{ ...crowdPose(t < 27.45 ? "idle" : "angry", i, f, t, 0), walk: rk > 0 ? -dz * WALK : undefined, speed: rk > 0 ? 1 : 0, arms: "up", armK: seg(t, 27.45 + i * 0.03, 27.7 + i * 0.03, Easing.out(Easing.back(2))), squash: t > 27.45 && t < 27.65 ? 0.12 : 0 }} />; })}
  </>);
};

/* =================== STAGE 3 square, Monday morning (31.41 – 34.77) =================== */
const FIRE = 33.74;
const S3: Shot[] = [
  { t0: 31.41, keys: [K(31.41, [3.0, 6.6, 13.5], [0.5, 9.5, -12], 58), K(32.2, [3.2, 7.4, 12.2], [0, 2.2, -2], 58), K(33.0, [3.0, 7.0, 11.6], [0, 2.0, -2], 58)] },
  { t0: 32.96, keys: [K(32.96, [-2.4, 3.5, 6.6], [-5.6, 3.1, -0.6], 54), K(34.0, [-2.2, 3.4, 6.2], [-5.4, 3.0, -0.6], 52), K(34.3, [1.8, 3.5, 7.6], [2.4, 2.4, -1.0], 54), K(34.9, [2.0, 3.4, 7.2], [2.4, 2.3, -1.0], 54)], impacts: [[FIRE, 0.03]] },
];
const Stage3 = ({ t, f }: Ctx) => {
  const day = seg(t, 31.45, 32.2, Easing.inOut(Easing.sin)), sunY = lerp(-2, 10, seg(t, 31.45, 32.5, Easing.out(Easing.quad)));
  const aim = seg(t, 33.1, 33.5, Easing.inOut(Easing.sin)), recoil = t > FIRE && t < FIRE + 0.25 ? Math.sin(clamp((t - FIRE) / 0.25) * Math.PI) : 0;
  const duck = seg(t, FIRE + 0.08, FIRE + 0.3, Easing.out(Easing.quad));
  const solds: V3[] = [[-6.2, 0, -1.6], [-5.6, 0, 0.2], [-6.8, 0, 1.8], [-5.4, 0, -3.4], [-7.0, 0, -0.4]];
  return (<>
    <Shots t={t} shots={S3} />
    <Lights warm="#ffe8c8" />
    <Sky t={t} top={day < 0.5 ? "#1a1a4a" : "#5a8ad8"} bottom={day < 0.5 ? "#7a4a6a" : "#ffd2a0"} stars={day < 0.4 ? 80 : 0} />
    <Ball p={[6, sunY, -60]} r={3.4} color="#ffe08a" ink={0} /><Glow p={[6, sunY, -59]} r={13} color="rgba(255,200,120,1)" o={0.4 + 0.4 * day} />
    <Surface p={[0, 0, -6]} s={[40, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#8a7a6e" b="#7a6a5e" unit={0.9} />
    {Array.from({ length: 7 }, (_, i) => <CanalHouse key={i} p={[-12 + i * 4, 0, -12]} w={3.9} h={7 + (i % 3)} color={HOUSE_COLS[(i + 1) % 8]} face="+z" gable={i % 2 ? "flat" : "step"} seed={i + 90} lit={0.3 * (1 - day)} />)}
    {[-10, -3, 4, 10].map((x) => <OldLamp key={x} p={[x, 0, -8]} on={1 - seg(t, 31.9, 32.2)} />)}
    <Cart p={[0.2, 0, -4.2]} rotY={Math.PI / 2} tip={0.5} /><Cart p={[0.0, 0, 2.4]} rotY={Math.PI / 2 + 0.2} tip={-0.45} />
    <Barrel p={[0.3, 0, -1.6]} /><Barrel p={[-0.2, 0, -0.6]} rot={[Math.PI / 2, 0, 0.3]} /><Barrel p={[0.5, 1.0, -1.2]} s={0.8} />
    <Crate p={[0.0, 0, 0.6]} /><Crate p={[0.2, 0.9, 0.4]} s={0.8} rotY={0.5} /><Crate p={[-0.1, 0, 4.4]} />
    {Array.from({ length: 14 }, (_, i) => <Box key={"st" + i} p={[0.4 + Math.sin(i * 3.1) * 0.5, 0.16 + (i % 3) * 0.28, -3 + i * 0.5]} s={[0.4, 0.28, 0.4]} color="#7a7a82" line={2} rot={[0, i, 0]} />)}
    <Box p={[0.1, 1.6, -1]} s={[0.12, 0.25, 6.6]} color="#a0682e" rot={[0.06, 0, 0.3]} />
    <CanvasPlane p={[0.6, 2.9, -2.2]} s={[1.4, 0.9]} rot={[0, 0.35, 0]} draw={(c, W, H) => { c.fillStyle = "#b3122e"; c.fillRect(0, 0, W, H); }} /><Cyl p={[0.6, 2.2, -2.9]} rt={0.04} h={2.4} color="#3a2a1a" line={1} />
    {[[2.2, -2.8], [2.6, -0.8], [2.0, 1.2], [3.2, 3.0], [3.6, -4.6]].map(([x, z], i) => <Person key={"r" + i} p={[x, 0, z]} h={3.0} look={folk[(i + 2) % 8]} f={f + i * 6} pose={{ mood: t < FIRE ? "angry" : "shock", arms: t < FIRE ? "up" : "head", armK: t < FIRE ? 0.6 + 0.3 * Math.sin(f * 0.3 + i) : 1, squash: -0.28 * duck, hunch: duck, flip: true, lookX: -1, nerv: t > FIRE ? 0.6 : 0.2 }} />)}
    {solds.map((P, i) => { const rT: [number, number] = [lerp(0.22, 0.24, aim), lerp(0.45, 0.62, aim) - 0.03 * recoil], lT: [number, number] = [lerp(-0.08, 0.38, aim), lerp(0.4, 0.62, aim)]; const mz = toWorld(P, hand(3.3, [rT[0] + 0.42 * aim, rT[1] + 0.02], 0, false, 0.15), camPos(t, S3));
      return <React.Fragment key={"s" + i}><Person p={P} h={3.3} look={soldier} f={f + i * 3} pose={{ mood: aim > 0.5 ? "angry" : "deadpan", armR: rT, armL: lT, armRK: 1, armLK: aim, lookX: 1, squash: -0.03 * recoil }} />
        <FaceGroup p={P}><Rifle p={hand(3.3, rT, 0, false, 0.14)} rot={[0, 0, lerp(-0.1, -Math.PI / 2, aim)]} s={1.1} /></FaceGroup>
        <Flash p={mz} t={t} t0={FIRE + i * 0.02} /><Smoke p={mz} t={t} t0={FIRE + i * 0.02} dir={[1, 0, 0]} /></React.Fragment>; })}
    <Shaft p={[3, 6, -6]} s={[5, 14]} rot={[0, 0, -0.35]} color="255,230,180" o={0.2 * day} /><Dust t={t} area={[6, 5, 4]} color="rgba(255,240,210,.9)" />
  </>);
};

/* =================== STAGE 4 dusk memorial (34.77 – 38.20) =================== */
const S4: Shot[] = [
  { t0: 34.77, keys: [K(34.77, [-8.6, 2.2, 3.4], [1.0, 2.9, -3.2], 56), K(36.2, [-7.2, 2.4, 3.7], [1.6, 2.9, -3.4], 56)] },
  { t0: 36.11, keys: [K(36.11, [3.0, 3.0, 0.6], [3.0, 3.9, -7.6], 52), K(38.4, [3.0, 3.0, -0.4], [3.0, 3.9, -7.6], 50)] },
];
const Stage4 = ({ t, f }: Ctx) => {
  const lit = (i: number) => seg(t, 34.82 + i * 0.034, 34.92 + i * 0.034);
  const wounded = Math.round(136 * seg(t, 36.31, 37.64, Easing.out(Easing.quad))), dead = seg(t, 34.8, 35.3);
  return (<>
    <Shots t={t} shots={S4} />
    <Lights warm="#c8d0ff" />
    <Sky t={t} top="#101a46" bottom="#e07a5a" stars={70} />
    <Water t={t} a="#123a5a" b="rgba(200,220,255,1)" w={60} d={6} p={[0, 0, -3]} />
    <Surface p={[0, Q, 3.5]} s={[60, 7]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#6a6a7a" b="#5a5a6a" unit={1.0} /><BrickWall p={[0, Q / 2 - 0.5, 0]} s={[60, Q + 1]} a="#5a2a2a" b="#4a2222" repeat={REP_Q} />
    <Surface p={[0, Q, -9]} s={[60, 6]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#5a5a6a" b="#4a4a5a" unit={1.0} /><BrickWall p={[0, Q / 2 - 0.5, -6]} s={[60, Q + 1]} a="#5a2a2a" b="#4a2222" repeat={REP_Q} />
    {Array.from({ length: 8 }, (_, i) => <CanalHouse key={i} p={[-14 + i * 4, Q, -14.5]} w={3.9} h={7.5 + (i % 3)} color={HOUSE_COLS[(i + 4) % 8]} face="+z" gable={["step", "bell", "flat"][i % 3] as "step"} seed={i + 120} lit={0.35} />)}
    {Array.from({ length: 26 }, (_, i) => { const x = -9.6 + i * 0.78, z = -3 + Math.sin(i * 1.3) * 0.5, y = 0.12 + Math.sin(t * 1.5 + i) * 0.03, k = lit(i);
      return <React.Fragment key={i}><Box p={[x, y, z]} s={[0.34, 0.3, 0.34]} color={k > 0.5 ? "#ffd27a" : "#e8e0d0"} line={2} />{k > 0 ? <Glow p={[x, y + 0.2, z]} r={0.9} color="rgba(255,190,90,1)" o={0.85 * k} /> : null}</React.Fragment>; })}
    <group position={[3.0, Q, -7.6]}>
      {[-1.6, 1.6].map((x) => <Cyl key={x} p={[x, 1.4, 0]} rt={0.08} h={2.8} color="#3a2a1a" line={2} />)}
      <CanvasPlane p={[0, 2.5, 0.05]} s={[3.6, 2.3]} px={[540, 345]} frame="#3a2a1a" draw={(c, W, H) => { c.fillStyle = "#1e2a22"; c.fillRect(0, 0, W, H); c.fillStyle = "#f4efe4"; c.textAlign = "center"; c.font = "700 34px Georgia, serif"; c.fillText("JORDAAN  •  26 JULI 1886", W / 2, 50, W - 40);
        c.globalAlpha = dead; c.font = "900 96px Georgia, serif"; c.fillStyle = "#ff8a7a"; c.fillText("26 DEAD", W / 2, 160, W - 40); c.globalAlpha = 1;
        if (t > 36.28) { c.font = "900 62px Georgia, serif"; c.fillStyle = "#ffd27a"; c.fillText(`${wounded} WOUNDED`, W / 2, 265, W - 40); } }} />
    </group>
    <Glow p={[3.0, 3.4, -7.0]} r={3.2} color="rgba(255,200,140,1)" o={0.22} />
    {[[-2.4, -8.4], [-1.2, -8.9], [0.0, -8.2], [6.2, -8.6], [7.4, -8.3]].map(([x, z], i) => <Person key={"mo" + i} p={[x, Q, z]} h={3.0} look={folk[(i + 5) % 8]} f={f + i * 9} pose={{ mood: "worry", hunch: 0.7, arms: "chest", armK: 1, squash: 0.01 * Math.sin(f * 0.1 + i) }} />)}
    {[-6, 0, 6, 12].map((x) => <OldLamp key={x} p={[x, Q, -6.6]} on={1} />)}<OldLamp p={[2.0, Q, 1.2]} on={1} />
    <Bollard p={[-4, Q, 0.4]} /><Bollard p={[0, Q, 0.4]} /><Bollard p={[4, Q, 0.4]} /><Barrel p={[8.0, Q, 2.6]} /><Crate p={[5.2, Q, 3.4]} s={0.8} />
  </>);
};

/* =================== STAGE 5 the Jordaan: poor, crowded, furious (38.20 – 44.15) =================== */
const S5: Shot[] = [
  { t0: 38.2, keys: [K(38.2, [0.4, 3.9, 10.5], [0, 3.4, -2], 56), K(40.6, [0.2, 3.6, 8.8], [0, 3.3, -2], 54)] },
  { t0: 40.58, keys: [K(40.58, [-1.6, 3.5, 3.9], [-0.6, 3.5, 0], 46), K(42.4, [1.6, 3.5, 3.9], [0.6, 3.5, 0], 46)] },
  { t0: 42.39, keys: [K(42.39, [1.8, 2.3, 8.4], [0.3, 0.1, 4.5], 46), K(43.4, [1.5, 2.1, 7.9], [0.1, 0.1, 4.4], 42), K(44.3, [1.4, 2.1, 7.8], [0.0, 0.15, 4.3], 42)], fovKick: [43.4] },
];
const coil: V3[] = Array.from({ length: 22 }, (_, i) => { const a = i * 0.55, r = 0.15 + i * 0.045; return [0.4 + Math.cos(a) * r, 0.05, 4.6 + Math.sin(a) * r * 0.8] as V3; });
const Stage5 = ({ t, f }: Ctx) => {
  const copZ = lerp(-9, 1.0, seg(t, 38.3, 42.3, Easing.linear)), sp = clamp((t - 42.45) / 0.95), si = Math.min(coil.length - 1, Math.floor(sp * (coil.length - 1)));
  const boom = t > 43.4 ? 1 - seg(t, 43.4, 44.0) : 0;
  const resid: [number, number][] = [[-3.4, 1.6], [-2.6, -0.2], [-3.2, -2.4], [3.2, 1.2], [2.7, -1.0], [3.4, -3.2], [-3.0, 4.2], [3.0, 4.0], [-1.0, -0.4], [1.0, -0.2], [0.0, -0.6], [-2.2, -5.2], [2.2, -5.6]];
  return (<>
    <Shots t={t} shots={S5} />
    <StreetSet t={t} f={f} sky={["#2a2a6a", "#d86a4a"]} lit={0.5} lamps={1} />
    {[-3, -9].map((z, i) => <Laundry key={"wl" + i} a={[-4.3, 5.1 + i * 0.3, z]} b={[4.3, 5.3, z]} t={t + i} sag={0.5} n={i ? 5 : 4} seed={2 + i * 3} />)}
    {resid.map(([x, z], i) => <Person key={"res" + i} p={[x, 0, z]} h={i > 7 ? 3.1 : 2.4 + (i % 3) * 0.3} look={folk[(i + 2) % 8]} f={f + i * 5} pose={{ mood: t > 40.9 ? "angry" : i % 3 ? "worry" : "deadpan", hunch: 0.25, lookX: x > 0 ? -1 : 1, arms: t > 40.9 && i % 2 ? "chest" : "down", armK: seg(t, 40.9, 41.2), nerv: 0.1, squash: 0.01 * Math.sin(f * 0.2 + i) }} />)}
    <Person p={[0.2, 0, copZ]} h={3.4} look={cop} f={f} pose={{ mood: "deadpan", walk: (copZ + 9) * WALK, speed: 0.7, lookX: Math.sin(t * 1.5) }} />
    <Rope pts={coil} r={0.035} />
    {t > 42.45 && t < 43.45 ? <><Glow p={coil[si]} r={0.5} color="rgba(255,200,80,1)" o={1} />{[0, 1, 2].map((k) => <Ball key={k} p={[coil[si][0] + Math.sin(f * 1.7 + k * 2) * 0.12, 0.12 + ((f + k * 3) % 6) * 0.04, coil[si][2] + Math.cos(f * 1.3 + k) * 0.12]} r={0.025} color="#ffd36a" ink={0} />)}</> : null}
    <Barrel p={[-0.9, 0, 3.4]} s={0.8} />
    {boom > 0 ? <Glow p={[-0.9, 0.8, 3.6]} r={3.0 * (1.2 - boom * 0.2)} color="rgba(255,190,90,1)" o={0.9 * boom} /> : null}
  </>);
};

/* =================== STAGE 6 What if? Same canal, he walks past (44.15 – 49.30) =================== */
const S6: Shot[] = [
  { t0: 44.15, keys: [K(44.15, [-1.6, 3.3, 9.8], [-5.6, 4.0, 4.6], 56), K(47.0, [-1.4, 3.3, 5.2], [-5.4, 4.4, 0.0], 54)] },
  { t0: 46.99, keys: [K(46.99, [1.4, 4.65, 3.4], [0, 4.75, 0], 48), K(48.0, [1.3, 4.62, 3.2], [0, 4.75, 0], 47)] },
  { t0: 47.92, keys: [K(47.92, [2.6, 2.3, 5.2], [0.2, 5.0, 0.4], 58), K(49.4, [2.8, 2.2, 4.8], [0.2, 5.1, 0.6], 56)] },
];
const GW0 = 44.2, GW1 = 46.95, GJ = 47.95;
const Stage6 = ({ t, f }: Ctx) => {
  const wz = lerp(6.0, -1.8, seg(t, GW0, GW1, Easing.linear)), P: V3 = [-5.6, Q, wz], moving = t > GW0 && t < GW1 && !(t > 45.46 && t < 45.95);
  const bz = (t - 48.25) * 1.5, j = jump(t, GJ, 0.75, 1.95), got = t > 48.25, by = boatY(t, t > GJ + 0.75 ? 0.1 * Math.exp(-(t - GJ - 0.75) * 5) : 0);
  const HP: V3 = [0.15, by + 0.72 + j.y, bz + 0.55];
  const ropeSag = got ? SAG - 0.9 + 0.35 * Math.exp(-(t - 48.25) * 3) * Math.cos((t - 48.25) * 9) : SAG;
  const hL = toWorld(HP, hand(3.0, [-0.07, 1.0], j.sq, false, 0.1), camPos(t, S6));
  return (<>
    <Shots t={t} shots={S6} />
    <CanalWorld t={t} f={f} sky={["#4ab0f0", "#e8fbff"]} water={["#2a9aa0", "rgba(240,255,255,1)"]} sun={[24, 28, -66]} sunC="#fff8d0" crowd={t > 48.4 ? "cheer" : "idle"} skipLeftNear />
    <Rope pts={sagPts(TOPL, TOPR, ropeSag)} /><Rope pts={[TOPL, CLEAT]} />
    {!got ? <Eel p={EEL0} t={t} wig={1.3} /> : <Eel p={hL} t={t} wig={1.6} ang={-Math.PI / 2} />}
    <Person p={P} h={3.4} look={cop} f={f} pose={{ mood: t > 45.3 && t < 46.4 ? "smile" : "deadpan", walk: (6.0 - wz) * WALK, speed: moving ? 0.6 : 0, arms: t > 45.46 && t < 46.2 ? "shrug" : "down", armK: seg(t, 45.46, 45.7, Easing.out(Easing.back(2))) * (1 - seg(t, 45.95, 46.2)), lookX: t > 45.0 && t < 46.1 ? 0.9 : -0.3 }} />
    {t > 47.2 ? <><Rowboat p={[0.3, by, bz]} />
      <Person p={HP} sy={by + 0.72} h={3.0} look={henk} f={f} shadow={false} pose={{ mood: got ? "laugh" : "grin", squash: j.sq, air: j.inAir ? 1 : 0, arms: "up", armK: seg(t, GJ - 0.3, GJ), armR: got ? [0.07, 1.0] : undefined, armL: got ? [-0.07, 1.0] : undefined, armRK: 1, armLK: 1 }} />
      <Person p={[0.45, by + 0.72, bz - 1.25]} sy={by + 0.72} h={3.0} look={poler} f={f + 11} shadow={false} pose={{ mood: got ? "laugh" : "smile", arms: got ? "up" : "hold", armK: 1 }} /></> : null}
    {got ? <Glow p={hL} r={1.6} color="rgba(255,240,160,1)" o={0.35 * (1 - seg(t, 48.4, 49.1))} /> : null}
  </>);
};

/* =================== STAGE 7 home at sunset -> Tuesday dawn (49.30 – 52.92) =================== */
const S7: Shot[] = [
  { t0: 49.3, keys: [K(49.3, [-2.6, 2.8, 8.6], [-4.4, 3.3, 2.0], 56), K(50.7, [-0.4, 2.8, 8.6], [-1.6, 3.3, 2.0], 56)] },
  { t0: 50.66, keys: [K(50.66, [0, 4.6, 12.4], [0, 5.2, -10], 58), K(53.0, [0, 4.9, 13.2], [0, 5.0, -12], 58)] },
];
const Stage7 = ({ t, f }: Ctx) => {
  const sunset = seg(t, 49.3, 50.7, Easing.in(Easing.quad)), night = seg(t, 50.66, 50.85) * (1 - seg(t, 51.1, 51.4)), dawn = seg(t, 51.15, 51.8);
  const sunY = t < 50.7 ? lerp(6, -4, sunset) : lerp(-4, 7, dawn), sunX = t < 50.7 ? 8 : -9, moonA = seg(t, 50.66, 51.35, Easing.linear);
  const topC = night > 0.5 ? "#0a0f30" : t < 50.7 ? "#5a3a8a" : "#7ab0f0", botC = night > 0.5 ? "#2a2a6a" : t < 50.7 ? "#ff8a5a" : "#ffe2b0";
  const opened = Math.floor(26 * seg(t, 51.3, 52.4, Easing.linear)), perHouse = [7, 7, 6, 6];
  let rest = opened; const opens = perHouse.map((n) => { const o = Math.min(n, rest); rest -= o; return o; });
  const walkX = (i: number) => lerp(-4.2 - i * 0.9, -0.2 - i * 0.9, seg(t, 49.3, 50.8, Easing.linear));
  return (<>
    <Shots t={t} shots={S7} />
    <Lights warm={night > 0.5 ? "#8aa0ff" : "#ffd8b0"} />
    <Sky t={t} top={topC} bottom={botC} stars={night > 0.5 ? 140 : 0} />
    <Ball p={[sunX, sunY, -60]} r={3.2} color="#ffd36a" ink={0} /><Glow p={[sunX, sunY, -59]} r={12} color="rgba(255,180,110,1)" o={0.6 * (1 - night)} />
    {moonA > 0 && moonA < 1 ? <Ball p={[lerp(10, -10, moonA), 4 + Math.sin(moonA * Math.PI) * 14, -58]} r={2.0} color="#f4f0dc" ink={0.05} /> : null}
    <Water t={t} a={night > 0.5 ? "#0e2a4a" : "#2a6a8a"} b="rgba(230,240,255,1)" w={60} d={6} p={[0, 0, -3]} />
    <Surface p={[0, Q, 3.5]} s={[60, 7]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#8a7a6e" b="#7a6a5e" unit={1.0} /><BrickWall p={[0, Q / 2 - 0.5, 0]} s={[60, Q + 1]} a="#7a3222" b="#6a2a1e" repeat={REP_Q} />
    <Surface p={[0, Q, -9]} s={[60, 6]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#8a7a6e" b="#7a6a5e" unit={1.0} /><BrickWall p={[0, Q / 2 - 0.5, -6]} s={[60, Q + 1]} a="#7a3222" b="#6a2a1e" repeat={REP_Q} />
    {[0, 1, 2, 3].map((i) => <CanalHouse key={i} p={[-6 + i * 4, Q, -14.5]} w={3.9} h={9.2} color={HOUSE_COLS[(i * 3 + 1) % 8]} face="+z" gable={i % 2 ? "bell" : "step"} seed={i + 150} lit={1} openN={t < 50.66 ? 0 : opens[i]} />)}
    {[-10, 10, 14].map((x, i) => <CanalHouse key={"n" + i} p={[x, Q, -14.5]} w={3.9} h={8} color={HOUSE_COLS[(i + 5) % 8]} face="+z" gable="flat" seed={i + 170} lit={0.1} />)}
    {[-8, -2, 4, 10].map((x) => <OldLamp key={x} p={[x, Q, -6.8]} on={night > 0.2 || t < 50.66 ? 1 : 0} />)}
    <Tree p={[-11, Q, -8.6]} /><Tree p={[11.5, Q, -8.8]} color="#4aa84a" /><Rowboat p={[-3, 0.05, -3]} rotY={Math.PI / 2} color="#2f5a8a" /><Rowboat p={[5, 0.05, -2.6]} rotY={Math.PI / 2} color="#7a3a2a" />
    <Bollard p={[-6, Q, 0.4]} /><Bollard p={[0, Q, 0.4]} /><Bollard p={[6, Q, 0.4]} /><Barrel p={[-9, Q, 2.6]} /><Crate p={[9, Q, 3]} />
    {t < 50.9 ? Array.from({ length: 5 }, (_, i) => { const x = walkX(i), P: V3 = [x, Q, 1.9 + (i % 2) * 0.6]; const lk = i === 0 ? henk : i === 1 ? poler : folk[(i + 1) % 8];
      return <React.Fragment key={"w" + i}><Person p={P} h={3.0} look={lk} f={f + i * 7} pose={{ mood: "laugh", walk: (x + 4.2 + i * 0.9) * WALK, speed: 0.8, arms: "up", armK: i === 0 ? 1 : 0.4 + 0.3 * Math.sin(f * 0.3 + i), armR: i === 0 ? [0.07, 1.0] : undefined, armL: i === 0 ? [-0.07, 1.0] : undefined, armRK: 1, armLK: 1, squash: 0.03 * Math.sin(f * 0.5 + i) }} />
        {i === 0 ? <Eel p={toWorld(P, hand(3.0, [-0.07, 1.0], 0, false, 0.1), camPos(t, S7))} t={t} wig={1.2} ang={-Math.PI / 2} /> : null}</React.Fragment>; }) : null}
    {[-6, -2, 2, 6].map((x, i) => { const out = seg(t, 51.6 + i * 0.18, 52.1 + i * 0.18, Easing.out(Easing.quad)); return out > 0 ? <Person key={"wk" + i} p={[x, Q, lerp(-12.0, -10.4, out)]} h={3.0} look={folk[(i + 2) % 8]} f={f + i * 5} pose={{ mood: t > 52.3 ? "smile" : "deadpan", arms: "up", armK: seg(t, 52.0 + i * 0.12, 52.4 + i * 0.12), squash: 0.05 * Math.sin(clamp((t - 52.1 - i * 0.15) / 0.5) * Math.PI) }} /> : null; })}
    <Shaft p={[-4, 7, -8]} s={[5, 14]} rot={[0, 0, 0.4]} color="255,220,160" o={0.2 * dawn} />
  </>);
};

/* =================== STAGE 8 the frozen moment (52.92 – 57.0) =================== */
const S8: Shot[] = [
  { t0: 52.92, keys: [K(52.92, [1.2, 3.8, 5.8], [-4.2, 4.4, 0.4], 56), K(54.2, [-0.6, 3.5, 5.4], [-4.3, 4.4, 0.6], 52)] },
  { t0: 54.11, keys: [K(54.11, [-3.1, 3.5, 3.2], [-4.2, 3.3, 0.6], 44), K(54.8, [-3.2, 3.5, 3.0], [-4.2, 3.3, 0.6], 42)] },
  { t0: 54.7, keys: [K(54.7, [1.2, 7.6, 16.5], [0, 4.6, -6], 60), K(55.7, [0.6, 9.4, 14.2], [0, 4.4, -6], 60)] },
  { t0: 55.6, keys: [K(55.6, [-2.4, 3.0, 3.4], [-4.0, 2.75, 0.4], 46), K(57.1, [-2.55, 2.95, 3.2], [-4.0, 2.8, 0.3], 44)], impacts: [[55.92, 0.01]] },
];
const HCUT = 55.92;
const Stage8 = ({ t, f }: Ctx) => {
  const kT: [number, number] = t < 55.6 ? KN_UP : t < HCUT ? [lerp(KN_UP[0], KN_CUT[0], seg(t, 55.6, HCUT, Easing.in(Easing.quad))), lerp(KN_UP[1], KN_CUT[1], seg(t, 55.6, HCUT, Easing.in(Easing.quad)))] : [lerp(KN_CUT[0], 0.14, seg(t, HCUT, HCUT + 0.1)), lerp(KN_CUT[1], 0.36, seg(t, HCUT, HCUT + 0.1))];
  const cutP = toWorld(OFF1, hand(3.4, KN_CUT, 0, false, 0.08), camAt(HCUT, S8[3].keys).pos as V3);
  const snapped = t >= HCUT, up = seg(t, HCUT, HCUT + 0.5, Easing.out(Easing.quad)), fl = Math.sin((t - HCUT) * 14) * Math.exp(-(t - HCUT) * 3) * 0.15;
  const breath = Math.sin(t * 1.4) * 0.012;
  return (<>
    <Shots t={t} shots={S8} />
    <CanalWorld t={23.3} f={699} sky={["#2a1a5a", "#c25a6a"]} water={["#14405a", "rgba(200,220,255,1)"]} sun={[-30, 10, -66]} sunC="#ffb08a" crowd="idle" skipLeftNear />
    <Rope pts={sagPts(TOPL, TOPR, SAG)} />
    {!snapped ? <Rope pts={[TOPL, cutP, CLEAT]} /> : <><Rope pts={[TOPL, [lerp(cutP[0], TOPL[0], up * 0.3) + fl, lerp(cutP[1], TOPL[1], up * 0.3), cutP[2]]]} /><Rope pts={[CLEAT, [cutP[0] - fl, lerp(cutP[1], CLEAT[1] - 0.4, up), cutP[2] + 0.05]]} /></>}
    <Eel p={EEL0} t={snapped ? t : 23.3} wig={snapped ? 2.2 : 1.1} eyeShock={snapped} />
    <Person p={OFF1} h={3.4} look={cop} f={699} pose={{ mood: t > 54.7 ? "worry" : "deadpan", armR: kT, armRK: 1, lookX: 0.5, squash: breath, nerv: t > 55.0 ? 0.2 : 0, sweat: t > 54.0 ? 1 : 0 }} />
    <FaceGroup p={OFF1}><Knife p={hand(3.4, kT, breath, false, 0.12)} rot={[0, 0, t < 55.6 ? -0.2 : -0.9]} s={1.25} glint={0.6 * (0.5 + 0.5 * Math.sin(t * 3))} /></FaceGroup>
    <Glow p={cutP} r={0.8} color="rgba(255,255,255,1)" o={snapped && t < HCUT + 0.15 ? 1 : 0} />
    <Glow p={[OFF1[0], 3.4, OFF1[2]]} r={4.5} color="rgba(255,230,200,1)" o={0.22} />
    <Dust t={53.1} area={[6, 6, 4]} color="rgba(255,240,220,.9)" />
    {void f}
  </>);
};

/* =================== pop texts (top band) + word captions =================== */
type Pop = { a: number; b: number; parts: [string, string][] };
const Y = "#FFE830", R = "#FF5C4A", Wt = "#FFFFFF";
const F1 = 1 / FPS, FX = 12 / FPS; // ends: 1 frame after a hard cut / 6 frames before a crossfade (crossfade starts 6 frames early)
const POPS: Pop[] = [
  { a: 0, b: 1.75 + F1, parts: [["ONE ROPE.", Wt], ["|", Wt], ["26 LIVES.", Y]] },
  { a: 1.8, b: 3.86 + F1, parts: [["26 PEOPLE", Y]] },
  { a: 4.12, b: 6.23 + F1, parts: [["SUNDAY ", Wt], ["25 JULY 1886", Y]] },
  { a: 6.71, b: 8.68 + F1, parts: [["AMSTERDAM", Wt]] },
  { a: 11.65, b: 12.73 + F1, parts: [["LINDENGRACHT", Wt]] },
  { a: 18.5, b: 19.93, parts: [["EEL PULLING", Wt]] },
  { a: 19.93, b: 20.56 + F1, parts: [["BANNED", R]] },
  { a: 20.69, b: 22.49 + F1, parts: [["1 ", Y], ["OFFICER", Wt]] },
  { a: 26.7, b: 28.42 + F1, parts: [["JORDAAN", Wt]] },
  { a: 31.57, b: 32.96 + F1, parts: [["MONDAY", Y]] },
  { a: 34.77, b: 36.11 + F1, parts: [["26 DEAD", R]] },
  { a: 36.31, b: 38.2 - FX, parts: [["136 WOUNDED", R]] },
  { a: 38.93, b: 40.58 + F1, parts: [["JORDAAN", Wt], ["|", Wt], ["POOR, CROWDED", Wt]] },
  { a: 41.1, b: 42.39 + F1, parts: [["FURIOUS", R]] },
  { a: 44.3, b: 46.99 + F1, parts: [["WHAT IF?", Wt]] },
  { a: 50.66, b: 52.02, parts: [["26 WAKE UP", Y]] },
  { a: 52.02, b: 52.92 - FX, parts: [["TUESDAY", Y]] },
  { a: 54.11, b: 54.7 + F1, parts: [["1 KNIFE", Y]] },
  { a: 54.96, b: 55.6 + F1, parts: [["OR 1 CITY?", Wt]] },
];
export const POPS011 = POPS;
const AB = "'Archivo Black', Arial Black, sans-serif";
const PopText: React.FC<{ t: number }> = ({ t }) => {
  const p = POPS.find((x) => t >= x.a && t < x.b); if (!p) return null;
  const lines: [string, string][][] = [[]]; p.parts.forEach((q) => { if (q[0] === "|") lines.push([]); else lines[lines.length - 1].push(q); });
  const n = Math.max(...lines.map((l) => l.reduce((s, q) => s + q[0].length, 0))), fs = Math.min(lines.length > 1 ? 78 : 84, (720 * 0.88) / (n * 0.74));
  const k = interpolate(t - p.a, [0, 0.16], [0.55, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.back(2.4)) });
  return <div style={{ position: "absolute", left: 0, right: 0, top: 100, height: 230, display: "flex", alignItems: "center", justifyContent: "center" }}>
    <div style={{ fontFamily: AB, fontSize: fs, lineHeight: 1.08, textAlign: "center", transform: `scale(${k}) rotate(${(1 - k) * -6}deg)`, WebkitTextStroke: `${Math.round(fs * 0.16)}px #10101a`, paintOrder: "stroke fill", textShadow: "0 7px 0 rgba(0,0,0,.55)", whiteSpace: "nowrap" }}>
      {lines.map((l, j) => <div key={j}>{l.map(([s, c], i) => <span key={i} style={{ color: c }}>{s}</span>)}</div>)}
    </div></div>;
};
type Grp = { text: string; a: number };
const groups: Grp[] = (() => {
  const g: Grp[] = []; let cur: number[] = [];
  const flush = () => { if (cur.length) { g.push({ text: cur.map((i) => String(SCRIPT[i]).replace(/[.,!?;:]$/, "")).join(" "), a: words[cur[0]].start }); cur = []; } };
  words.forEach((_, i) => { cur.push(i); if (cur.length === 2 || /[.,!?;:]$/.test(String(SCRIPT[i]))) flush(); });
  flush(); return g;
})();
const WordCaps: React.FC<{ t: number }> = ({ t }) => {
  const idx = groups.findIndex((g, i) => t >= g.a - 0.02 && t < (groups[i + 1]?.a ?? 99) - 0.02); if (idx < 0) return null; const g = groups[idx];
  const sc = interpolate(t - g.a, [0, 0.1], [0.8, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.back(2.6)) });
  const fs = Math.min(76, 640 / (g.text.length * 0.72));
  return <div style={{ position: "absolute", left: 20, right: 20, top: 900 - fs * 0.55, textAlign: "center", fontFamily: AB, fontSize: fs, lineHeight: 1.05, color: "#fff", WebkitTextStroke: "11px #000", paintOrder: "stroke fill", transform: `scale(${sc})`, textShadow: "0 7px 0 rgba(0,0,0,.45)", whiteSpace: "nowrap" }}>{g.text.toUpperCase()}</div>;
};

let fontHandle: number | null = null;
const ThumbText: React.FC<{ parts: [string, string][] }> = ({ parts }) => {
  const lines: [string, string][][] = [[]]; parts.forEach((q) => { if (q[0] === "|") lines.push([]); else lines[lines.length - 1].push(q); });
  const n = Math.max(...lines.map((l) => l.reduce((s, q) => s + q[0].length, 0))), fs = Math.min(118, (720 * 0.9) / (n * 0.74));
  return <div style={{ position: "absolute", left: 0, right: 0, top: 90, height: 300, display: "flex", alignItems: "center", justifyContent: "center" }}>
    <div style={{ fontFamily: AB, fontSize: fs, lineHeight: 1.04, textAlign: "center", WebkitTextStroke: `${Math.round(fs * 0.17)}px #10101a`, paintOrder: "stroke fill", textShadow: "0 9px 0 rgba(0,0,0,.6)", whiteSpace: "nowrap" }}>
      {lines.map((l, j) => <div key={j}>{l.map(([s, c], i) => <span key={i} style={{ color: c }}>{s}</span>)}</div>)}
    </div></div>;
};
/* props: clean hides pop texts and word captions (thumbnail stills); thumb draws a big thumbnail text */
export const Eel011: React.FC<Record<string, unknown>> = (props) => {
  const clean = props.clean === true, thumb = props.thumb as [string, string][] | undefined;
  const [h] = React.useState(() => { if (fontHandle === null) { fontHandle = delayRender("archivo"); const hh = fontHandle; document.fonts.load(`80px "Archivo Black"`).then(() => continueRender(hh)).catch(() => continueRender(hh)); } return 0; }); void h;
  const f = useCurrentFrame(), t = f / FPS;
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <Audio src={staticFile("mix.wav")} />
      <Scene first start={0} end={26.1} bg="#3a86e0">{(c) => <Stage1 {...c} />}</Scene>
      <Scene start={26.1} end={31.41} bg="#4a1a4a" trans="flash">{(c) => <Stage2 {...c} />}</Scene>
      <Scene start={31.41} end={34.77} bg="#1a1a4a">{(c) => <Stage3 {...c} />}</Scene>
      <Scene start={34.77} end={38.2} bg="#101a46">{(c) => <Stage4 {...c} />}</Scene>
      <Scene start={38.2} end={44.15} bg="#2a2a6a" trans="zoom">{(c) => <Stage5 {...c} />}</Scene>
      <Scene start={44.15} end={49.3} bg="#4ab0f0" trans="rewind">{(c) => <Stage6 {...c} />}</Scene>
      <Scene start={49.3} end={52.92} bg="#ff8a5a" trans="whip">{(c) => <Stage7 {...c} />}</Scene>
      <Scene start={52.92} end={DUR011 / FPS} bg="#2a1a5a">{(c) => <Stage8 {...c} />}</Scene>
      <Grade t={t} shaft={false} tint={t < 26.1 ? "rgba(255,170,60,.05)" : t < 31.41 ? "rgba(255,60,30,.10)" : t < 34.77 ? "rgba(120,150,200,.07)" : t < 38.2 ? "rgba(40,60,200,.10)" : t < 44.15 ? "rgba(120,40,120,.08)" : t < 49.3 ? "rgba(120,255,200,.05)" : t < 52.92 ? "rgba(255,140,90,.07)" : "rgba(90,40,160,.14)"} />
      {!clean && <PopText t={t} />}
      {!clean && <WordCaps t={t} />}
      {thumb && <ThumbText parts={thumb} />}
    </AbsoluteFill>
  );
};
void Bollard; void Tree; void PL;
