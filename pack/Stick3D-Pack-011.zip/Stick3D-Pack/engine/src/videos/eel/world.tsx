// Shared world for Short 011 (eel riot): cast, scene wrapper with transitions, canal + street sets, jump helper.
import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame, Easing, Audio, staticFile } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { Box, Cyl, Ball, CanvasPlane, Surface, BrickWall, INK } from "../../style/toon";
import { Look } from "../../style/puppet";
import { Person, Lights, Grade, seg, lerp, clamp, V3 } from "../../style/kit";
import { Glow, Shaft, Dust, Plant } from "../../style/props";
import { Cam, Key, camAt, FaceGroup, hand } from "../../style/extra";
import { CanalHouse, Rowboat, Eel, Rope, sagPts, Knife, Rifle, Barrel, Crate, Bollard, Cart, Tree, OldLamp, Poster, Splash, Smoke, Flash, fitText, Laundry, Skyline, Clouds } from "../../style/oldtown";

export const FPS = 30, LEAD = 6, TAIL = 8, WALK = 3.4;
export type Ctx = { t: number; f: number };
export type Trans = "ghost" | "zoom" | "flash" | "whip" | "rewind";

/* ---------- cast (1886) ---------- */
export const cop: Look = { skin: "#f6d6bd", body: "#1c2a55", outfit: "suit", tie: "#1c2a55", hair: "short", hairColor: "#3b2a1a", hat: "#1c2a55", hatStyle: "kepi", hatBand: "#ffc23a", shoe: "#0b0d1a" };
export const henk: Look = { skin: "#f1c9a5", body: "#d8462a", outfit: "shirt", hair: "short", hairColor: "#6a3a1a", hat: "#4a3a2a", hatStyle: "cap", shoe: "#2a1a12" };
export const poler: Look = { skin: "#e0b48c", body: "#2f6bb0", outfit: "shirt", hair: "short", hairColor: "#222", hat: "#2a2a3a", hatStyle: "cap", shoe: "#1b1b2a" };
export const soldier: Look = { skin: "#f6d6bd", body: "#2a3a5e", outfit: "suit", tie: "#2a3a5e", hair: "short", hairColor: "#222", hat: "#2a3a5e", hatStyle: "kepi", hatBand: "#b3122e", shoe: "#0b0d1a" };
export const folk: Look[] = [
  { skin: "#fbe3c8", body: "#7a4a2a", outfit: "shirt", hair: "short", hairColor: "#222", hat: "#3a2a1a", hatStyle: "cap" }, { skin: "#e8b890", body: "#c23b3b", outfit: "blazer", shirt: "#f4efe4", hair: "bob", hairColor: "#5a3420" },
  { skin: "#f6d6bd", body: "#3a5a3a", outfit: "suit", tie: "#7a1a22", hair: "grey", hat: "#1b1b2a" }, { skin: "#c98e62", body: "#e0a83a", outfit: "shirt", hair: "swept", hairColor: "#1a1010", hat: "#5a4a3a", hatStyle: "cap" },
  { skin: "#fbe3c8", body: "#5a3a6a", outfit: "blazer", shirt: "#fff", hair: "bob", hairColor: "#c47a2a" }, { skin: "#f1d0b0", body: "#2d4a6a", outfit: "shirt", hair: "short", hairColor: "#3b2a1a", hat: "#2a2a2a", hatStyle: "cap" },
  { skin: "#e0b48c", body: "#8a2a2a", outfit: "suit", tie: "#1d2f66", hair: "short", hairColor: "#111", hat: "#111" }, { skin: "#f7d4b5", body: "#4a7a8a", outfit: "blazer", shirt: "#f4efe4", hair: "bob", hairColor: "#222" },
];

/* ---------- scene wrapper (NvidiaV4 + a new "rewind" transition) ---------- */
export const Scene: React.FC<{ start: number; end: number; first?: boolean; trans?: Trans; bg: string; children: (c: Ctx) => React.ReactNode }> = ({ start, end, first, trans = "ghost", bg, children }) => {
  const from = Math.round(start * FPS) - (first ? 0 : LEAD), dur = Math.round(end * FPS) - from + TAIL;
  return <Sequence from={from} durationInFrames={dur} layout="none"><Inner from={from} first={first} trans={trans} bg={bg} children={children} /></Sequence>;
};
const Inner: React.FC<{ from: number; first?: boolean; trans: Trans; bg: string; children: (c: Ctx) => React.ReactNode }> = ({ from, first, trans, bg, children }) => {
  const f = useCurrentFrame(), t = (f + from) / FPS;
  const k = first ? 1 : clamp(f / (LEAD + 2)), ke = Easing.out(Easing.cubic)(k);
  const kr = clamp(f / 16);
  const sc = !first && trans === "zoom" ? lerp(1.35, 1, ke) : 1;
  const tx = !first && trans === "whip" ? (1 - ke) * 720 : !first && trans === "rewind" ? Math.sin(f * 2.1) * 24 * (1 - kr) : 0;
  const blur = !first && trans === "whip" ? (1 - ke) * 14 : !first && trans === "rewind" ? (1 - kr) * 6 : 0;
  const extra = !first && trans === "rewind" ? ` sepia(${(1 - kr).toFixed(2)}) hue-rotate(${((1 - kr) * 40).toFixed(0)}deg)` : "";
  const op = first || trans === "flash" || trans === "whip" ? 1 : trans === "rewind" ? clamp(f / 5) : k;
  return (
    <AbsoluteFill style={{ opacity: op, transform: `translateX(${tx}px) scale(${sc})`, background: bg, filter: `saturate(1.32) contrast(1.07) brightness(1.02)${extra}${blur > 0.2 ? ` blur(${blur.toFixed(1)}px)` : ""}` }}>
      <ThreeCanvas width={720} height={1280} camera={{ fov: 60, position: [0, 2, 8], near: 0.1, far: 220 }} gl={{ antialias: true }}>
        <color attach="background" args={[bg]} />{children({ t, f })}
      </ThreeCanvas>
      {!first && trans === "flash" ? <AbsoluteFill style={{ background: "#fff", opacity: 1 - clamp(f / 7) }} /> : null}
      {!first && trans === "rewind" && kr < 1 ? <AbsoluteFill style={{ background: "repeating-linear-gradient(0deg, rgba(255,255,255,.18) 0 3px, rgba(0,0,0,0) 3px 9px)", opacity: 1 - kr }} /> : null}
    </AbsoluteFill>
  );
};
export const yawTo = (cam: V3, p: V3) => Math.atan2(cam[0] - p[0], cam[2] - p[2]);
export const toWorld = (p: V3, loc: V3, cam: V3): V3 => { const y = yawTo(cam, p); return [p[0] + loc[0] * Math.cos(y) + loc[2] * Math.sin(y), p[1] + loc[1], p[2] - loc[0] * Math.sin(y) + loc[2] * Math.cos(y)]; };
export const up1 = (v: V3, dy: number): V3 => [v[0], v[1] + dy, v[2]];

/* ---------- shared canal world (canal along z, quays at y = Q) ---------- */
export const Q = 1.0, CW = 3.4, PL: V3 = [-4.0, Q, 0], PR: V3 = [4.0, Q, 0], PH = 5.8; // poles 5.8 high, eel head at y 5.0 (1.2 higher than v1) so jumpers must leap for it
export const TOPL: V3 = [PL[0], Q + PH, 0.0], TOPR: V3 = [PR[0], Q + PH, 0.0], CLEAT: V3 = [PL[0] + 0.12, Q + 0.85, 0.16];
export const SAG = 1.8, EEL0: V3 = [0, Q + PH - SAG, 0];
export const BR_Z = -11, BR_Y = Q + 0.75;
export const REP_Q: [number, number] = [30, 1.4];
export const HOUSE_COLS = ["#7a2e22", "#8a4a2a", "#3a4a5a", "#a8642e", "#5a2a22", "#c9b08a", "#2e4a3a", "#6a3a4a"];
export const Water: React.FC<{ t: number; a: string; b: string; w?: number; d?: number; p?: V3 }> = ({ t, a, b, w = 7, d = 80, p = [0, 0, -20] }) => (<>
  <Surface p={p} s={[w, d]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={a} b={a} />
  <CanvasPlane p={[p[0], p[1] + 0.01, p[2]]} rot={[-Math.PI / 2, 0, 0]} s={[w, d]} px={[160, 1200]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = b; c.lineWidth = 3; for (let i = 0; i < 90; i++) { const y = ((i * 97) % H + t * 18) % H, x = (i * 53) % W; c.globalAlpha = 0.35 + 0.35 * Math.sin(t * 2 + i); c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + 14, y - 4, x + 28, y); c.stroke(); } c.globalAlpha = 1; }} />
</>);
const hexA = (h: string, a: number) => { const n = parseInt(h.slice(1, 7), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
// sky gradient + far skyline with a church tower (haze in the top colour) + drifting clouds when there are no stars
export const Sky: React.FC<{ t: number; top: string; bottom: string; stars?: number; z?: number; skyline?: boolean }> = ({ t, top, bottom, stars = 0, z = -70, skyline = true }) => (<>
  {/* tall sky plane (y -60..240, x -230..230) so low cameras looking up never see the empty background; horizon colour at y 0..10 */}
  <CanvasPlane p={[0, 90, z]} s={[460, 300]} px={[640, 760]} draw={(c, W, H) => {
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, top); g.addColorStop(0.64, top); g.addColorStop(0.79, bottom); g.addColorStop(1, bottom); c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let i = 0; i < stars * 2; i++) { const x = ((i * 7919) % 1000) / 1000 * W, y = ((i * 104729) % 1000) / 1000 * H * 0.76, tw = 0.5 + 0.5 * Math.sin(t * 3 + i); c.fillStyle = `rgba(255,255,240,${0.35 + 0.65 * tw})`; c.beginPath(); c.arc(x, y, 0.8 + (i % 3) * 0.6, 0, 7); c.fill(); }
  }} />
  {stars === 0 ? <Clouds p={[0, 22, z + 3]} s={[190, 34]} t={t} color={top.startsWith("#") && parseInt(top.slice(1, 3), 16) > 0x40 && parseInt(top.slice(5, 7), 16) > 0x90 ? "rgba(255,255,255,.6)" : "rgba(255,226,214,.42)"} /> : null}
  {skyline ? <Skyline p={[0, 15, z + 10]} s={[170, 30]} color={hexA(top, stars > 0 ? 0.75 : 0.5)} tower={0.56} /> : null}
</>);

export type CanalOpt = { t: number; f: number; sky: [string, string]; water: [string, string]; lit?: number; lamps?: number; sun?: V3; sunC?: string; crowd?: "idle" | "cheer" | "shock" | "angry" | "none"; crowdT?: number; noRope?: boolean; poster?: boolean; skipLeftNear?: boolean; dim?: number };
export const crowdSpots: { p: V3; flip?: boolean }[] = [
  { p: [-6.4, Q, 4.6] }, { p: [-7.4, Q, 2.6] }, { p: [-6.0, Q, -2.4] }, { p: [-7.2, Q, -5.2] }, { p: [-5.6, Q, -7.6] },
  { p: [5.8, Q, 4.0], flip: true }, { p: [7.0, Q, 1.6], flip: true }, { p: [5.4, Q, -1.8], flip: true }, { p: [6.8, Q, -4.6], flip: true }, { p: [5.6, Q, -7.4], flip: true },
  { p: [-3.0, BR_Y, BR_Z + 0.4] }, { p: [-1.8, BR_Y, BR_Z - 0.3] }, { p: [-0.6, BR_Y, BR_Z + 0.5] }, { p: [0.6, BR_Y, BR_Z - 0.2] }, { p: [1.8, BR_Y, BR_Z + 0.4] }, { p: [3.0, BR_Y, BR_Z - 0.3] },
];
export const crowdPose = (mode: string, i: number, f: number, t: number, ct: number) => {
  const ph = Math.sin(f * 0.25 + i * 1.7);
  if (mode === "cheer") return { mood: (i % 3 ? "laugh" : "grin") as "laugh" | "grin", arms: "up" as const, armK: 0.6 + 0.4 * Math.abs(ph), squash: 0.04 * ph, lookX: i < 5 ? 1 : -1 };
  if (mode === "shock") { const k = seg(t, ct, ct + 0.25); return { mood: "shock" as const, arms: (i % 2 ? "head" : "up") as "head" | "up", armK: k, squash: t < ct + 0.15 ? -0.08 * k : 0, nerv: 0.4, lookX: i < 5 ? 1 : -1 }; }
  if (mode === "angry") return { mood: "angry" as const, arms: "up" as const, armK: 0.7 + 0.3 * ph, squash: 0.03 * ph, nerv: 0.2, lookX: i < 5 ? 1 : -1 };
  return { mood: (i % 3 === 0 ? "smile" : "deadpan") as "smile" | "deadpan", lookX: i < 5 ? 1 : -1, squash: 0.01 * ph };
};
export const CanalWorld: React.FC<CanalOpt> = ({ t, f, sky, water, lit = 0.15, lamps = 0, sun, sunC = "#ffd36a", crowd = "idle", crowdT = 0, noRope, poster = true, skipLeftNear, dim = 0 }) => (<>
  <Lights warm="#ffe2b8" />
  <Sky t={t} top={sky[0]} bottom={sky[1]} stars={lamps > 0.5 ? 120 : 0} />
  {sun ? <><Ball p={sun} r={3.2} color={sunC} ink={0} /><Glow p={sun} r={12} color="rgba(255,210,120,1)" o={0.7} /></> : null}
  <Water t={t} a={water[0]} b={water[1]} />
  {[-1, 1].map((s) => <React.Fragment key={s}>
    <BrickWall p={[s * CW, Q / 2 - 0.5, -20]} rot={[0, -s * Math.PI / 2, 0]} s={[80, Q + 1]} a="#8a3a2a" b="#7a3222" repeat={REP_Q} />
    <Surface p={[s * 6.2, Q, -20]} s={[5.6, 80]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#9a8a7a" b="#8a7a6a" unit={1.0} />
    <Box p={[s * (CW + 0.12), Q + 0.06, -20]} s={[0.24, 0.12, 80]} color="#c9b8a0" line={2} />
  </React.Fragment>)}
  {/* houses both sides + a row closing the canal */}
  {Array.from({ length: 9 }, (_, i) => { const z = 9 - i * 3.7, h = 7.5 + ((i * 5) % 4) * 0.9; return <React.Fragment key={i}>
    <CanalHouse p={[-11.5, Q, z]} w={3.6} h={h} color={HOUSE_COLS[i % 8]} face="+x" gable={i % 3 === 1 ? "bell" : i % 3 === 2 ? "flat" : "step"} seed={i + 1} lit={lit} stone={i === 2 ? "ANNO 1886" : undefined} />
    <CanalHouse p={[11.5, Q, z - 1.6]} w={3.6} h={h + 0.6} color={HOUSE_COLS[(i + 3) % 8]} face="-x" gable={i % 3 === 0 ? "bell" : i % 3 === 1 ? "step" : "flat"} seed={i + 21} lit={lit} />
  </React.Fragment>; })}
  {Array.from({ length: 5 }, (_, i) => <CanalHouse key={"e" + i} p={[-8 + i * 4, Q, -28]} w={3.8} h={8 + (i % 2) * 1.5} color={HOUSE_COLS[(i + 5) % 8]} face="+z" gable={i % 2 ? "step" : "bell"} seed={i + 40} lit={lit} />)}
  {/* bridge */}
  <Box p={[0, BR_Y - 0.25, BR_Z]} s={[CW * 2 + 2.4, 0.5, 3.0]} color="#9a6a4a" />
  <CanvasPlane p={[0, (BR_Y - 0.5) / 2 - 0.2, BR_Z + 1.52]} s={[CW * 2, BR_Y + 0.1]} px={[340, 90]} draw={(c, W, H) => { c.fillStyle = "#8a3a2a"; c.fillRect(0, 0, W, H); c.fillStyle = "#1a1420"; c.beginPath(); c.ellipse(W / 2, H, W * 0.42, H * 0.95, 0, Math.PI, 0); c.fill(); c.strokeStyle = INK; c.lineWidth = 5; c.stroke(); }} />
  {[-1, 1].map((s) => <React.Fragment key={"r" + s}><Box p={[0, BR_Y + 0.45, BR_Z + s * 1.4]} s={[CW * 2 + 2.4, 0.12, 0.12]} color="#1f2a30" line={2} />{[-4, -2, 0, 2, 4].map((x) => <Box key={x} p={[x, BR_Y + 0.22, BR_Z + s * 1.4]} s={[0.1, 0.45, 0.1]} color="#1f2a30" line={1} />)}</React.Fragment>)}
  {poster ? <><Box p={[-4.7, Q + 1.3, BR_Z + 1.9]} s={[0.22, 2.6, 0.22]} color="#3a2a1a" line={2} /><Poster p={[-4.7, Q + 2.1, BR_Z + 2.05]} title="VERBODEN" sub="Eel-pulling|is forbidden" s={0.9} /></> : null}
  {/* moored boats, bollards, lamps, trees, barrels, crates, flowers */}
  <Rowboat p={[-2.2, 0.05, 6.5]} rotY={0.08} color="#2f5a8a" /><Rowboat p={[2.3, 0.05, -6.0]} rotY={-0.06} color="#7a3a2a" /><Rowboat p={[-2.3, 0.05, -16]} color="#3a6a3a" />
  {[-1, 1].map((s) => [7, 2.5, -3, -8, -14].map((z) => <Bollard key={s + "b" + z} p={[s * 3.8, Q, z]} />))}
  {[-1, 1].map((s) => [5.5, -5.5, -16].map((z) => <OldLamp key={s + "l" + z} p={[s * 4.6, Q, z]} on={lamps} />))}
  <Tree p={[-8.2, Q, 7.0]} s={0.9} /><Tree p={[8.4, Q, -8.6]} s={1.0} color="#4aa84a" /><Tree p={[-8.0, Q, -13.0]} s={0.95} color="#2f8a42" />
  <Barrel p={[-8.2, Q, 0.4]} /><Barrel p={[-8.6, Q, -0.8]} s={0.9} /><Crate p={[7.9, Q, 2.8]} /><Crate p={[8.4, Q, 3.8]} s={0.7} rotY={0.4} /><Cart p={[8.0, Q, -1.6]} rotY={Math.PI / 2} />
  <Plant p={[-8.6, Q, 5.0]} s={0.8} pot="#5a3a22" /><Plant p={[8.6, Q, -5.8]} s={0.8} pot="#5a3a22" />
  {/* rope poles + the festival sign */}
  {[PL, PR].map((p, i) => <React.Fragment key={"pole" + i}><Cyl p={[p[0], Q + PH / 2, p[2]]} rt={0.1} rb={0.15} h={PH} color="#5a3a22" line={2} /><Ball p={[p[0], Q + PH + 0.05, p[2]]} r={0.15} color="#3a2a1a" ink={0.03} /></React.Fragment>)}
  <Box p={[CLEAT[0] + 0.02, CLEAT[1], CLEAT[2] - 0.04]} s={[0.12, 0.12, 0.3]} color="#3a3a4a" line={2} />
  <CanvasPlane p={[PL[0] - 0.02, Q + 3.6, 0.2]} rot={[0, 0.25, 0]} s={[1.9, 1.0]} px={[380, 200]} frame="#3a2a1a" draw={(c, W, H) => { c.fillStyle = "#e8c98a"; c.fillRect(0, 0, W, H); c.textAlign = "center"; c.fillStyle = "#7a1a22"; fitText(c, "PALINGTREKKEN", W / 2, 66, W - 44, 46); c.fillStyle = "#2a1a12"; fitText(c, "Zondag 25 Juli", W / 2, 120, W - 60, 36, 800); fitText(c, "1886", W / 2, 174, W - 60, 48); }} />
  {!noRope ? <Rope pts={sagPts(TOPR, TOPL, 0.0, 1)} r={0.0001} /> : null}
  {crowd !== "none" ? crowdSpots.map((s, i) => (skipLeftNear && i < 2) ? null : <Person key={"c" + i} p={s.p} h={3.0} look={folk[i % 8]} f={f + i * 7} pose={{ ...crowdPose(crowd, i, f, t, crowdT + (i % 4) * 0.05), flip: s.flip }} />) : null}
  <Dust t={t} area={[6, 6, 4]} color="rgba(255,240,200,.9)" />
  {dim > 0 ? <Glow p={[0, 4, 0]} r={0.01} color="rgba(0,0,0,0)" o={0} /> : null}
</>);

/* ---------- jump-to-the-eel (anticipation -> air -> landing squash) ---------- */
export const jump = (t: number, t0: number, air = 0.9, peak = 0.8) => {
  const u = clamp((t - t0) / air), y = t > t0 && t < t0 + air ? Math.sin(u * Math.PI) * peak : 0;
  const land = t >= t0 + air ? Math.max(0, 1 - (t - t0 - air) / 0.3) : 0;
  const sq = t < t0 - 0.16 ? 0 : t < t0 ? -0.18 * seg(t, t0 - 0.16, t0, Easing.linear) : t < t0 + air ? 0.14 : -0.3 * land;
  return { y, sq, inAir: y > 0 };
};
export const boatY = (t: number, dip = 0) => 0.05 + Math.sin(t * 2.2) * 0.03 - dip;

/* =================== street set for the riot (houses facing a cobbled street along z) =================== */
export const StreetSet: React.FC<{ t: number; f: number; sky: [string, string]; lit: number; lamps: number; stars?: number }> = ({ t, f, sky, lit, lamps, stars = 0 }) => (<>
  <Lights warm="#ffc890" />
  <Sky t={t} top={sky[0]} bottom={sky[1]} stars={stars} />
  <Surface p={[0, 0, -20]} s={[8.6, 80]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#7a6a5e" b="#6a5a50" unit={0.8} />
  {Array.from({ length: 10 }, (_, i) => { const z = 10 - i * 3.8; return <React.Fragment key={i}>
    <CanalHouse p={[-6.7, 0, z]} w={3.8} h={6.2 + (i % 3) * 0.6} color={HOUSE_COLS[(i + 2) % 8]} face="+x" gable={(["step", "flat", "bell", "flat"] as const)[i % 4]} seed={i + 60} lit={lit} />
    <CanalHouse p={[6.7, 0, z - 1.2]} w={3.8} h={6.6 + (i % 2) * 0.8} color={HOUSE_COLS[(i + 6) % 8]} face="-x" gable={(["bell", "flat", "step", "flat"] as const)[i % 4]} seed={i + 80} lit={lit} />
  </React.Fragment>; })}
  {[6, -2, -10, -18].map((z, i) => <React.Fragment key={"l" + i}><OldLamp p={[-3.9, 0, z]} on={lamps} /><OldLamp p={[3.9, 0, z - 3]} on={lamps} /></React.Fragment>)}
  <Barrel p={[-3.4, 0, 3.2]} /><Barrel p={[3.3, 0, -4.4]} s={0.9} /><Crate p={[-3.3, 0, -7.0]} /><Cart p={[3.0, 0, 1.2]} rotY={Math.PI / 2 + 0.2} /><Crate p={[3.4, 0, -12]} s={0.8} />
  <Bollard p={[-3.8, 0, -1.0]} /><Bollard p={[3.8, 0, 4.4]} />
  {/* laundry line across the street */}
  <Laundry a={[-4.3, 5.5, -6]} b={[4.3, 5.7, -6]} t={t} sag={0.6} n={5} seed={0} />
  <Laundry a={[-4.3, 5.9, -15]} b={[4.3, 5.8, -15]} t={t + 1} sag={0.5} n={4} seed={3} />
  <Dust t={t} area={[4, 6, 5]} color="rgba(255,220,170,.9)" />
  {void f}
</>);

