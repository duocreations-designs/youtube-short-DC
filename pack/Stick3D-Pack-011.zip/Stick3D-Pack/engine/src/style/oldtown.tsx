// Old-town props (eel-riot, 1886 Amsterdam). Logged in rules/ACTION-LIBRARY.md.
import React from "react";
import * as THREE from "three";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3, clamp } from "./kit";
import { Glow } from "./props";
import { Extrude } from "./extra";

/* ---------- a cylinder between two world points (ropes, poles, oars, rifles) ---------- */
const UP = new THREE.Vector3(0, 1, 0);
export const Seg: React.FC<{ a: V3; b: V3; r?: number; color?: string; line?: number }> = ({ a, b, r = 0.035, color = "#c9a66b", line = 1 }) => {
  const d = new THREE.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]); const L = Math.max(0.001, d.length());
  const e = new THREE.Euler().setFromQuaternion(new THREE.Quaternion().setFromUnitVectors(UP, d.normalize()));
  return <Cyl p={[(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]} rt={r} h={L} color={color} line={line} rot={[e.x, e.y, e.z]} />;
};
// rope as a polyline through points
export const Rope: React.FC<{ pts: V3[]; r?: number; color?: string }> = ({ pts, r = 0.04, color = "#d8b47a" }) => (
  <>{pts.slice(1).map((p, i) => <Seg key={i} a={pts[i]} b={p} r={r} color={color} />)}</>
);
// sagging span a->b (parabolic sag), n segments
export const sagPts = (a: V3, b: V3, sag: number, n = 12): V3[] => Array.from({ length: n + 1 }, (_, i) => { const u = i / n; return [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u - sag * 4 * u * (1 - u), a[2] + (b[2] - a[2]) * u] as V3; });

/* ---------- canvas text that always fits its board: shrinks the font until the text is maxW wide or less ---------- */
export const fitText = (c: CanvasRenderingContext2D, txt: string, x: number, y: number, maxW: number, px: number, weight = 900, fam = "Georgia, 'DejaVu Serif', serif") => {
  let z = px; c.font = `${weight} ${z}px ${fam}`; while (z > 8 && c.measureText(txt).width > maxW) { z -= 1; c.font = `${weight} ${z}px ${fam}`; }
  c.fillText(txt, x, y);
};

/* ---------- Amsterdam canal house (local facade faces +z; face rotates it) ---------- */
type Face = "+z" | "+x" | "-x";
const faceRot = (f: Face) => (f === "+z" ? 0 : f === "+x" ? Math.PI / 2 : -Math.PI / 2);
export const CanalHouse: React.FC<{ p: V3; w: number; h: number; d?: number; color: string; face?: Face; gable?: "step" | "bell" | "flat"; seed?: number; lit?: number; openN?: number; frame?: string; stone?: string; door?: string }> = ({ p, w, h, d = 5, color, face = "+z", gable = "step", seed = 1, lit = 0.2, openN = -1, frame = "#f4efe4", stone, door = "#2c5a3a" }) => {
  const gh = gable === "flat" ? 0.9 : w * 0.85;
  const pts: [number, number][] = gable === "step"
    ? [[-w / 2, 0], [w / 2, 0], [w / 2, gh * 0.25], [w * 0.36, gh * 0.25], [w * 0.36, gh * 0.5], [w * 0.22, gh * 0.5], [w * 0.22, gh * 0.75], [w * 0.1, gh * 0.75], [w * 0.1, gh], [-w * 0.1, gh], [-w * 0.1, gh * 0.75], [-w * 0.22, gh * 0.75], [-w * 0.22, gh * 0.5], [-w * 0.36, gh * 0.5], [-w * 0.36, gh * 0.25], [-w / 2, gh * 0.25]]
    : gable === "bell"
      ? [[-w / 2, 0], [w / 2, 0], [w * 0.42, gh * 0.3], [w * 0.28, gh * 0.55], [w * 0.22, gh * 0.85], [w * 0.12, gh], [-w * 0.12, gh], [-w * 0.22, gh * 0.85], [-w * 0.28, gh * 0.55], [-w * 0.42, gh * 0.3]]
      : [[-w / 2 - 0.15, 0], [w / 2 + 0.15, 0], [w / 2 + 0.15, gh], [-w / 2 - 0.15, gh]];
  const cols = Math.max(2, Math.round(w / 1.3)), rows = Math.max(2, Math.round((h - 1.6) / 1.7));
  return (
    <group position={p} rotation={[0, faceRot(face), 0]}>
      <Box p={[0, h / 2, 0]} s={[w, h, d]} color={color} />
      <Box p={[0, h + 0.5, -0.6]} s={[w * 0.7, 1.0, d - 1.4]} color="#3a2a2a" line={2} />
      <Box p={[(seed % 2 ? 1 : -1) * w * 0.22, h + 1.35, -1.6]} s={[0.42, 1.3, 0.42]} color="#7a3a2a" line={2} /><Box p={[(seed % 2 ? 1 : -1) * w * 0.22, h + 2.05, -1.6]} s={[0.56, 0.14, 0.56]} color="#3a2a2a" line={2} />
      <Extrude pts={pts} depth={0.3} color={gable === "flat" ? "#efe6d6" : color} p={[0, h, d / 2 - 0.15]} line={3} />
      {gable !== "flat" ? <><Box p={[0, h + gh + 0.3, d / 2 + 0.1]} s={[0.16, 0.5, 0.7]} color="#3a2a2a" line={2} /><Box p={[0, h + gh * 0.55, d / 2 + 0.25]} s={[0.12, 0.12, 0.9]} color="#3a2a2a" line={2} /></> : null}
      <CanvasPlane p={[0, h / 2, d / 2 + 0.02]} s={[w * 0.98, h * 0.98]} px={[Math.round(w * 40), Math.round(h * 40)]} draw={(c, W, H) => {
        c.fillStyle = color; c.fillRect(0, 0, W, H);
        c.strokeStyle = "rgba(0,0,0,.13)"; c.lineWidth = 1.5; for (let y = 0; y < H; y += 8) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
        const cw = W / cols, rh = (H - 70) / rows; let n = seed * 31, k = 0;
        for (let r = 0; r < rows; r++) for (let q = 0; q < cols; q++) {
          n = (n * 9301 + 49297) % 233280; const on = n / 233280 < lit; const x = q * cw + cw * 0.2, y = 18 + r * rh, ww = cw * 0.6, hh = rh * 0.68;
          const isDoor = r === rows - 1 && q === Math.floor(cols / 2); if (isDoor) { c.fillStyle = door; c.fillRect(x, y + hh * 0.15, ww, H - y - hh * 0.15); c.strokeStyle = INK; c.lineWidth = 4; c.strokeRect(x, y + hh * 0.15, ww, H - y - hh * 0.15); c.fillStyle = "#ffc23a"; c.beginPath(); c.arc(x + ww * 0.8, y + hh * 0.9, 4, 0, 7); c.fill(); continue; }
          const open = openN < 0 || k < openN; k++;
          c.fillStyle = on && open ? "#ffd770" : "#1e2a44"; c.fillRect(x, y, ww, hh);
          c.strokeStyle = frame; c.lineWidth = 5; c.strokeRect(x, y, ww, hh); c.beginPath(); c.moveTo(x + ww / 2, y); c.lineTo(x + ww / 2, y + hh); c.moveTo(x, y + hh / 2); c.lineTo(x + ww, y + hh / 2); c.stroke();
          if (!open) { c.fillStyle = "#2f7a4a"; c.fillRect(x - 1, y - 1, ww + 2, hh + 2); c.strokeStyle = "#1a4a2a"; c.lineWidth = 2; for (let s = 1; s < 5; s++) { c.beginPath(); c.moveTo(x, y + hh * s / 5); c.lineTo(x + ww, y + hh * s / 5); c.stroke(); } c.beginPath(); c.moveTo(x + ww / 2, y); c.lineTo(x + ww / 2, y + hh); c.stroke(); }
          else if (openN >= 0) { c.fillStyle = "#2f7a4a"; c.fillRect(x - ww * 0.42, y, ww * 0.38, hh); c.fillRect(x + ww * 1.04, y, ww * 0.38, hh); }
          c.strokeStyle = INK; c.lineWidth = 2; c.strokeRect(x - 3, y - 3, ww + 6, hh + 6);
        }
        c.fillStyle = "rgba(255,255,255,.55)"; c.fillRect(0, H - 6, W, 6);
      }} />
      {stone ? <CanvasPlane p={[0, h + gh * 0.32, d / 2 + 0.02]} s={[w * 0.5, 0.55]} px={[260, 72]} frame={INK} draw={(c, W, H) => { c.fillStyle = "#efe6d6"; c.fillRect(0, 0, W, H); c.fillStyle = "#3a2a2a"; c.textAlign = "center"; c.textBaseline = "middle"; fitText(c, stone, W / 2, H / 2 + 3, W - 24, 50); }} /> : null}
    </group>
  );
};

/* ---------- rowboat (length along local z, deck top at y = 0.72) ---------- */
export const Rowboat: React.FC<{ p: V3; rotY?: number; color?: string; roll?: number }> = ({ p, rotY = 0, color = "#8a4a22", roll = 0 }) => (
  <group position={p} rotation={[0, rotY, roll]}>
    <group rotation={[0, Math.PI / 2, 0]}><Extrude pts={[[-1.8, 0.05], [1.5, 0.05], [2.3, 0.75], [-2.0, 0.75]]} depth={1.5} color={color} line={3} /></group>
    <Box p={[0, 0.73, -0.1]} s={[1.2, 0.04, 3.4]} color="#4a2a14" line={2} />
    <Box p={[0, 0.78, 0.4]} s={[1.3, 0.08, 0.35]} color="#c08a4a" line={2} />
    <Box p={[0, 0.45, 0]} s={[1.52, 0.1, 3.6]} color="#f2efe6" line={1} />
  </group>
);

/* ---------- the eel: hangs from its head at p; wig = wriggle phase; slick sheen ---------- */
export const Eel: React.FC<{ p: V3; t: number; wig?: number; ang?: number; s?: number; eyeShock?: boolean }> = ({ p, t, wig = 1, ang = 0, s = 1, eyeShock }) => {
  const n = 11;
  return (
    <group position={p} rotation={[0, 0, ang]} scale={s}>
      {Array.from({ length: n }, (_, i) => { const k = i / (n - 1); const x = Math.sin(t * 9 - k * 5) * 0.16 * k * wig, y = -k * 1.25; const r = 0.13 - 0.075 * k; return <Ball key={i} p={[x, y, 0]} r={r} color={i % 2 ? "#3f4d28" : "#465630"} ink={0.035} />; })}
      <Ball p={[0.05, 0.04, 0.1]} r={eyeShock ? 0.06 : 0.045} color="#ffffff" ink={0.015} /><Ball p={[0.06, 0.04, 0.15]} r={0.022} color={INK} ink={0} />
      {[0.2, 0.45, 0.7].map((k, i) => <Glow key={i} p={[Math.sin(t * 9 - k * 5) * 0.16 * k * wig - 0.04, -k * 1.25, 0.12]} r={0.16} color="rgba(255,255,255,1)" o={0.55 + 0.35 * Math.sin(t * 6 + i * 2)} />)}
    </group>
  );
};

/* ---------- small street props ---------- */
export const Knife: React.FC<{ p: V3; rot?: V3; s?: number; glint?: number }> = ({ p, rot, s = 1, glint = 0 }) => (
  <group position={p} rotation={rot} scale={s}>
    <Box p={[0, 0, 0]} s={[0.07, 0.2, 0.06]} color="#5a3420" line={2} /><Box p={[0, 0.22, 0]} s={[0.05, 0.26, 0.02]} color="#e8eef6" line={2} />
    {glint > 0 ? <Glow p={[0, 0.3, 0.05]} r={0.35} color="rgba(255,255,255,1)" o={glint} /> : null}
  </group>
);
export const Rifle: React.FC<{ p: V3; rot?: V3; s?: number }> = ({ p, rot, s = 1 }) => (
  <group position={p} rotation={rot} scale={s}>
    <Box p={[0, -0.25, 0]} s={[0.1, 0.55, 0.12]} color="#6a3a1a" line={2} /><Cyl p={[0, 0.5, 0]} rt={0.035} h={1.1} color="#3a3a4a" line={1} /><Box p={[0, 1.08, 0]} s={[0.02, 0.18, 0.02]} color="#c9d3e0" line={1} />
  </group>
);
export const Barrel: React.FC<{ p: V3; s?: number; rot?: V3 }> = ({ p, s = 1, rot }) => (
  <group position={p} scale={s} rotation={rot}><Cyl p={[0, 0.55, 0]} rt={0.45} rb={0.42} h={1.1} color="#9a5a2a" /><Cyl p={[0, 0.25, 0]} rt={0.47} h={0.07} color="#3a3a4a" line={1} /><Cyl p={[0, 0.85, 0]} rt={0.47} h={0.07} color="#3a3a4a" line={1} /></group>
);
export const Crate: React.FC<{ p: V3; s?: number; rotY?: number }> = ({ p, s = 1, rotY = 0 }) => (
  <group position={p} scale={s} rotation={[0, rotY, 0]}><Box p={[0, 0.45, 0]} s={[0.9, 0.9, 0.9]} color="#c08a4a" /><Box p={[0, 0.45, 0.46]} s={[0.84, 0.1, 0.02]} color="#8a5a2a" line={1} /><Box p={[0, 0.45, 0.46]} s={[0.1, 0.84, 0.02]} color="#8a5a2a" line={1} /></group>
);
export const Bollard: React.FC<{ p: V3; color?: string }> = ({ p, color = "#7a1a22" }) => (
  <group position={p}><Cyl p={[0, 0.4, 0]} rt={0.16} rb={0.2} h={0.8} color={color} line={2} /><Ball p={[0, 0.82, 0]} r={0.17} color={color} ink={0.03} /></group>
);
export const Cart: React.FC<{ p: V3; rotY?: number; tip?: number }> = ({ p, rotY = 0, tip = 0 }) => (
  <group position={p} rotation={[0, rotY, tip]}>
    <Box p={[0, 1.0, 0]} s={[2.4, 0.5, 1.4]} color="#a0682e" /><Cyl p={[0, 0.6, 0.78]} rt={0.6} h={0.12} color="#5a3420" line={2} rot={[Math.PI / 2, 0, 0]} /><Cyl p={[0, 0.6, -0.78]} rt={0.6} h={0.12} color="#5a3420" line={2} rot={[Math.PI / 2, 0, 0]} />
    <Box p={[1.9, 0.9, 0.35]} s={[1.6, 0.08, 0.08]} color="#5a3420" line={1} /><Box p={[1.9, 0.9, -0.35]} s={[1.6, 0.08, 0.08]} color="#5a3420" line={1} />
  </group>
);
export const Tree: React.FC<{ p: V3; s?: number; color?: string }> = ({ p, s = 1, color = "#3a9a4a" }) => (
  <group position={p} scale={s}><Cyl p={[0, 1.4, 0]} rt={0.14} rb={0.2} h={2.8} color="#5a3a22" line={2} /><Ball p={[0, 3.4, 0]} r={1.2} color={color} /><Ball p={[-0.7, 3.0, 0.2]} r={0.8} color={color} /><Ball p={[0.7, 3.1, -0.1]} r={0.85} color={color} /></group>
);
export const OldLamp: React.FC<{ p: V3; on?: number; h?: number }> = ({ p, on = 0, h = 3.6 }) => (
  <group position={p}><Cyl p={[0, h / 2, 0]} rt={0.06} rb={0.1} h={h} color="#1f2a30" line={2} /><Box p={[0, h + 0.25, 0]} s={[0.36, 0.5, 0.36]} color={on > 0 ? "#ffe9a8" : "#a8b8c0"} line={2} /><Cyl p={[0, h + 0.58, 0]} rt={0.0} rb={0.28} h={0.25} color="#1f2a30" line={2} />{on > 0 ? <Glow p={[0, h + 0.25, 0]} r={1.3} color="rgba(255,210,120,1)" o={0.7 * on} /> : null}</group>
);
export const Poster: React.FC<{ p: V3; rot?: V3; s?: number; title: string; sub?: string }> = ({ p, rot, s = 1, title, sub }) => (
  <CanvasPlane p={p} rot={rot} s={[1.5 * s, 1.9 * s]} px={[300, 380]} frame="#3a2a1a" draw={(c, W, H) => {
    const m = 44; // text stays inside the red border (border at 12..W-12, 8 px wide)
    c.fillStyle = "#f3e6c4"; c.fillRect(0, 0, W, H); c.strokeStyle = "#7a1a22"; c.lineWidth = 8; c.strokeRect(12, 12, W - 24, H - 24);
    c.textAlign = "center"; c.fillStyle = "#7a1a22"; fitText(c, "POLITIE", W / 2, 66, W - 2 * m, 30);
    c.fillStyle = "#1a1a1a"; fitText(c, title, W / 2, 150, W - 2 * m, 56); if (sub) sub.split("|").forEach((l, i) => fitText(c, l, W / 2, 206 + i * 38, W - 2 * m, 30, 700));
    c.fillStyle = "#3a2a1a"; fitText(c, "Amsterdam 1886", W / 2, H - 38, W - 2 * m, 24, 700);
  }} />
);
// expanding rings + droplets on the water at time t0 (y = water level)
export const Splash: React.FC<{ p: V3; t: number; t0: number }> = ({ p, t, t0 }) => {
  const d = t - t0; if (d < 0 || d > 2.2) return null;
  return (<>
    {[0, 0.25, 0.5].map((dl, i) => { const k = clamp((d - dl) / 1.4); if (k <= 0 || k >= 1) return null; return <CanvasPlane key={i} p={[p[0], p[1] + 0.03, p[2]]} rot={[-Math.PI / 2, 0, 0]} s={[0.4 + 3.6 * k, 0.4 + 3.6 * k]} px={[128, 128]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = `rgba(255,255,255,${0.9 * (1 - k)})`; c.lineWidth = 6; c.beginPath(); c.arc(W / 2, H / 2, W * 0.45, 0, 7); c.stroke(); }} />; })}
    {Array.from({ length: 9 }, (_, i) => { const a = i * 0.7, v: V3 = [Math.cos(a) * 1.6, 3.6 + (i % 3) * 0.8, Math.sin(a) * 1.6], y = p[1] + v[1] * d - 10 * d * d; return y > p[1] ? <Ball key={"d" + i} p={[p[0] + v[0] * d, y, p[2] + v[2] * d]} r={0.07} color="#cfefff" ink={0.02} /> : null; })}
  </>);
};
export const Smoke: React.FC<{ p: V3; t: number; t0: number; dir?: V3 }> = ({ p, t, t0, dir = [0, 0, 1] }) => {
  const d = t - t0; if (d < 0 || d > 2.5) return null;
  return <>{[0, 1, 2, 3].map((i) => { const k = clamp((d - i * 0.06) / 2.4); return <Glow key={i} p={[p[0] + dir[0] * (0.4 + k * 1.4) + i * 0.1, p[1] + k * 0.9, p[2] + dir[2] * (0.4 + k * 1.4)]} r={0.4 + k * 1.2} color="rgba(235,235,240,1)" o={0.75 * (1 - k)} />; })}</>;
};
// muzzle flash at the end of a rifle
export const Flash: React.FC<{ p: V3; t: number; t0: number }> = ({ p, t, t0 }) => { const d = t - t0; return d >= 0 && d < 0.12 ? <Glow p={p} r={0.9} color="rgba(255,230,140,1)" o={1} /> : null; };
void INK;

/* ---------- washing line with clothes (shirt, trousers, dress, sheet, socks) that sway; faces +z ---------- */
type Cloth = "shirt" | "pants" | "dress" | "sheet" | "socks";
const CLOTH: Cloth[] = ["shirt", "pants", "sheet", "dress", "socks", "shirt", "pants"];
const CLOTH_C = ["#f4efe4", "#c23b3b", "#3a6ab0", "#f0c040", "#6a9a5a", "#e89aa8", "#8a6a4a"];
const drawCloth = (c: CanvasRenderingContext2D, W: number, H: number, k: Cloth, col: string) => {
  c.clearRect(0, 0, W, H); c.fillStyle = col; c.strokeStyle = INK; c.lineWidth = 5; c.lineJoin = "round"; const P = (pts: number[][]) => { c.beginPath(); pts.forEach(([x, y], i) => (i ? c.lineTo(x * W, y * H) : c.moveTo(x * W, y * H))); c.closePath(); c.fill(); c.stroke(); };
  if (k === "shirt") { P([[0.3, 0.06], [0.7, 0.06], [0.96, 0.22], [0.86, 0.42], [0.76, 0.36], [0.76, 0.95], [0.24, 0.95], [0.24, 0.36], [0.14, 0.42], [0.04, 0.22]]); c.beginPath(); c.moveTo(0.5 * W, 0.1 * H); c.lineTo(0.5 * W, 0.9 * H); c.lineWidth = 3; c.stroke(); for (let i = 0; i < 4; i++) { c.fillStyle = INK; c.beginPath(); c.arc(0.55 * W, (0.25 + i * 0.18) * H, 3, 0, 7); c.fill(); } }
  else if (k === "pants") { P([[0.1, 0.05], [0.9, 0.05], [0.92, 0.96], [0.6, 0.96], [0.5, 0.36], [0.4, 0.96], [0.08, 0.96]]); c.fillStyle = "rgba(0,0,0,.18)"; c.fillRect(0.1 * W, 0.05 * H, 0.8 * W, 0.08 * H); }
  else if (k === "dress") { P([[0.34, 0.05], [0.66, 0.05], [0.7, 0.3], [0.95, 0.95], [0.05, 0.95], [0.3, 0.3]]); c.fillStyle = "rgba(255,255,255,.55)"; for (let i = 0; i < 6; i++) { c.beginPath(); c.arc((0.2 + i * 0.12) * W, 0.75 * H, 6, 0, 7); c.fill(); } }
  else if (k === "sheet") { P([[0.03, 0.05], [0.97, 0.05], [0.95, 0.9], [0.75, 0.96], [0.5, 0.9], [0.25, 0.96], [0.05, 0.9]]); c.strokeStyle = "rgba(60,90,160,.6)"; c.lineWidth = 6; for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(0.05 * W, i * 0.22 * H); c.lineTo(0.95 * W, i * 0.22 * H); c.stroke(); } }
  else { P([[0.08, 0.05], [0.4, 0.05], [0.4, 0.7], [0.46, 0.95], [0.1, 0.95], [0.08, 0.7]]); P([[0.58, 0.05], [0.9, 0.05], [0.92, 0.7], [0.9, 0.95], [0.54, 0.95], [0.6, 0.7]]); }
  c.fillStyle = "#8a5a32"; c.strokeStyle = INK; c.lineWidth = 2; [0.25, 0.75].forEach((x) => { c.fillRect(x * W - 4, 0, 8, 0.1 * H); c.strokeRect(x * W - 4, 0, 8, 0.1 * H); });
};
export const Laundry: React.FC<{ a: V3; b: V3; t: number; sag?: number; n?: number; seed?: number }> = ({ a, b, t, sag = 0.5, n = 5, seed = 0 }) => (<>
  <Rope pts={sagPts(a, b, sag, 10)} r={0.025} color="#e8e0d0" />
  {Array.from({ length: n }, (_, i) => {
    const u = (i + 0.6) / (n + 0.2), k = CLOTH[(i + seed) % CLOTH.length], col = CLOTH_C[(i * 3 + seed) % CLOTH_C.length];
    const [w, h] = k === "sheet" ? [1.25, 1.05] : k === "pants" ? [0.7, 1.05] : k === "dress" ? [0.85, 1.15] : k === "socks" ? [0.55, 0.5] : [1.0, 0.9];
    const x = a[0] + (b[0] - a[0]) * u, y = a[1] + (b[1] - a[1]) * u - sag * 4 * u * (1 - u), z = a[2] + (b[2] - a[2]) * u;
    return <group key={i} position={[x, y, z]} rotation={[Math.sin(t * 1.7 + i * 1.3) * 0.14, 0, Math.sin(t * 2.1 + i) * 0.05]}>
      <CanvasPlane p={[0, -h / 2, 0.02]} s={[w, h]} px={[Math.round(w * 110), Math.round(h * 110)]} draw={(c, W, H) => drawCloth(c, W, H, k, col)} />
    </group>;
  })}
</>);

/* ---------- far city skyline: gable roofs + one church tower with a crown, drawn in one haze colour ---------- */
export const Skyline: React.FC<{ p: V3; s: [number, number]; color: string; seed?: number; tower?: number }> = ({ p, s, color, seed = 3, tower = 0.64 }) => (
  <CanvasPlane p={p} s={s} px={[Math.round(s[0] * 12), Math.round(s[1] * 12)]} draw={(c, W, H) => {
    c.clearRect(0, 0, W, H); c.fillStyle = color; let x = 0, n = seed * 977 + 13;
    while (x < W) { n = (n * 9301 + 49297) % 233280; const r = n / 233280, w = W * (0.022 + r * 0.02), b = H, top = H * (0.58 - r * 0.2), kind = Math.floor(r * 3);
      c.beginPath(); c.moveTo(x, b); c.lineTo(x, top);
      if (kind === 0) { const st = w / 6; c.lineTo(x + st, top); c.lineTo(x + st, top - st); c.lineTo(x + 2 * st, top - st); c.lineTo(x + 2 * st, top - 2 * st); c.lineTo(x + 4 * st, top - 2 * st); c.lineTo(x + 4 * st, top - st); c.lineTo(x + 5 * st, top - st); c.lineTo(x + 5 * st, top); }
      else if (kind === 1) { c.quadraticCurveTo(x + w * 0.2, top - w * 0.25, x + w * 0.32, top - w * 0.55); c.lineTo(x + w * 0.68, top - w * 0.55); c.quadraticCurveTo(x + w * 0.8, top - w * 0.25, x + w, top); }
      else { c.lineTo(x + w / 2, top - w * 0.5); }
      c.lineTo(x + w, top); c.lineTo(x + w, b); c.closePath(); c.fill();
      if (r > 0.6) c.fillRect(x + w * 0.65, top - w * 0.75, w * 0.1, w * 0.4);
      x += w + W * 0.002; }
    const tx = W * tower, tw = W * 0.03; // church tower: body, 2 smaller stages, crown, spire
    c.fillRect(tx - tw / 2, H * 0.18, tw, H * 0.82); c.fillRect(tx - tw * 0.38, H * 0.1, tw * 0.76, H * 0.09); c.fillRect(tx - tw * 0.28, H * 0.04, tw * 0.56, H * 0.07);
    c.beginPath(); c.moveTo(tx - tw * 0.3, H * 0.045); c.quadraticCurveTo(tx, -H * 0.03, tx + tw * 0.3, H * 0.045); c.fill(); c.fillRect(tx - 1.5, -0, 3, H * 0.03);
  }} />
);
/* ---------- soft drifting clouds on a transparent plane ---------- */
export const Clouds: React.FC<{ p: V3; s: [number, number]; t: number; color?: string; n?: number }> = ({ p, s, t, color = "rgba(255,255,255,.55)", n = 7 }) => (
  <CanvasPlane p={p} s={s} px={[Math.round(s[0] * 8), Math.round(s[1] * 8)]} draw={(c, W, H) => {
    c.clearRect(0, 0, W, H); c.fillStyle = color;
    for (let i = 0; i < n; i++) { const cx = (((i * 0.173 + 0.05) * W + t * 6 * (1 + (i % 3) * 0.4)) % (W * 1.2)) - W * 0.1, cy = H * (0.15 + ((i * 37) % 60) / 100), r = H * (0.07 + (i % 3) * 0.025);
      c.beginPath(); c.ellipse(cx, cy, r * 2.4, r, 0, 0, 7); c.ellipse(cx - r * 1.1, cy + r * 0.25, r * 1.3, r * 0.8, 0, 0, 7); c.ellipse(cx + r * 1.2, cy + r * 0.2, r * 1.5, r * 0.85, 0, 0, 7); c.ellipse(cx + r * 0.2, cy - r * 0.45, r * 1.2, r * 0.9, 0, 0, 7); c.fill(); }
  }} />
);
