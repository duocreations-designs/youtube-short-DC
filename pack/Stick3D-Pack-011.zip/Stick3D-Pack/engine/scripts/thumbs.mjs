// usage: node thumbs.mjs <engineDir> <compId> <outDir> <scale> <jobs.json>  jobs: [{name, frame, parts:[[text,color],...]}]
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import fs from "node:fs"; import path from "node:path";
const [eng, id, out, scale, jobsFile] = process.argv.slice(2);
const jobs = JSON.parse(fs.readFileSync(jobsFile, "utf8"));
fs.mkdirSync(out, { recursive: true });
const serveUrl = await bundle({ entryPoint: path.join(eng, "src/index.ts"), webpackOverride: (c) => c });
const pw = ["/opt/pw-browsers/chromium_headless_shell", ...fs.readdirSync("/opt/pw-browsers").filter((d) => d.startsWith("chromium_headless_shell-")).map((d) => { const b = `/opt/pw-browsers/${d}`; const s = fs.readdirSync(b).find((x) => x.startsWith("chrome-headless-shell")); return s ? `${b}/${s}/chrome-headless-shell` : ""; })].find((x) => x && fs.existsSync(x) && fs.statSync(x).isFile());
const gl = fs.readFileSync(path.join(eng, "../.gl-flag"), "utf8").trim();
for (const j of jobs) {
  const inputProps = { clean: true, thumb: j.parts };
  const composition = await selectComposition({ serveUrl, id, inputProps, browserExecutable: pw, chromiumOptions: { gl } });
  await renderStill({ serveUrl, composition, frame: j.frame, inputProps, output: path.join(out, `${j.name}.png`), scale: Number(scale), browserExecutable: pw, chromiumOptions: { gl } });
  console.log("thumb", j.name, j.frame);
}
