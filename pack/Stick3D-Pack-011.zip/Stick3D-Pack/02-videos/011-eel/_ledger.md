# Anti-template ledger 011 Eel
video | scene | composition grammar | signature mechanic | entrances/transitions | environment/background | camera path | subject treatment
011 | S1 canal Sunday | canal along z, rope span, bridge crowd | eel pendulum at lens, boat jump + slip, 2nd jumper splash, knife cut, rope runs through ring, free fall + splash | first frame moving, 11 hard cuts | gold afternoon, step/bell/flat gables | push-in, pull-back, crane, water-level follow, ECU knife | eel, Henk, officer
011 | S2 riot street | street along z, houses both sides | rooftop throwers, stones + tiles on parabolas, police duck then flee, crowd chases | flash | dusk red, laundry lines | low angle up, tilt to roofs | mob, 3 police
011 | S3 square Monday | barricade across square | sunrise time-lapse, rifles shoulder->aim, volley flash + smoke, rioters duck | ghost | cool morning | crane down from sky, whip pan | soldiers vs rioters
011 | S4 memorial | canal along x, far quay | 26 lanterns light one by one, board counter to 136 | ghost | deep blue dusk | low diagonal, board push | mourners
011 | S5 Jordaan alley | crowded street | glaring residents, officer passes, rope coil burns like a fuse to "spark" | zoom | purple dusk | wide, lateral glide on faces, low CU on coil | residents
011 | S6 what-if canal | S1 layout, bright | officer shrugs and walks past, boatman wins the eel | rewind (sepia + scanlines) | pastel daylight | tracking, eel CU, hero low angle | officer, Henk
011 | S7 home -> Tuesday | canal along x, house row | walk home with eel overhead, sunset -> moon -> dawn, 26 shutters open, neighbours step out | whip | sunset to dawn | follow, crane wide | crowd
011 | S8 frozen moment | S1 layout, frozen | time stopped (water, crowd frozen), orbit, knife CU, city wide, final cut snap | ghost | purple night | orbit, CU, crane, ECU (callback of S1 cut) | officer
