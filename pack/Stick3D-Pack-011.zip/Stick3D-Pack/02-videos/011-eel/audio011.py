#!/usr/bin/env python3
"""Short 011 sound: own 120 bpm music (5 styles + 3 dead stops), ambience beds per set, sparse-but-dense SFX on action frames,
then mix under the voice (music+FX 16-21 dB below voice), -14 LUFS, true peak <= -1 dBTP.
usage: audio011.py <voice.wav> <cuts.json> <sfxdir> <outdir>"""
import sys, json, wave, subprocess, re, numpy as np
VOICE, CUTS, SFXD, OUT = sys.argv[1:5]
SR = 48000; DUR = 57.0; N = int(SR * DUR); rng = np.random.default_rng(11)
def rd(p):
    w = wave.open(p); sr = w.getframerate(); ch = w.getnchannels(); x = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
    if ch > 1: x = x.reshape(-1, ch).mean(1)
    if sr != SR: x = np.interp(np.arange(int(len(x) * SR / sr)) / SR, np.arange(len(x)) / sr, x)
    return x
def wr(p, x):
    w = wave.open(p, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes()); w.close()
def T(d): return np.arange(int(SR * d)) / SR
def add(buf, x, t, g=1.0):
    i = int(t * SR);
    if i >= len(buf): return
    L = min(len(x), len(buf) - i); buf[i:i + L] += x[:L] * g
def bp(x, lo, hi):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); X[(f < lo) | (f > hi)] = 0; return np.fft.irfft(X, len(x))
def env(d, a=0.005, r=None):
    t = T(d); e = np.minimum(1, t / a); return e * (np.exp(-t * (r if r else 4 / d)))
def hz(m): return 440 * 2 ** ((m - 69) / 12)

# ---------------- music ----------------
BEAT = 0.5; mus = np.zeros(N)
def tuba(m, d=0.42): t = T(d); f = hz(m); return (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(4 * np.pi * f * t) + 0.2 * np.sin(6 * np.pi * f * t)) * env(d, 0.012, 7)
def pluck(m, d=0.35): t = T(d); f = hz(m); return (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t + 0.3)) * env(d, 0.003, 12)
def bell(m, d=0.6): t = T(d); f = hz(m); return (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t * 9)) * env(d, 0.002, 6)
def kick(d=0.3): t = T(d); f = 50 + 90 * np.exp(-t * 25); return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(d, 0.002, 14)
def hat(d=0.05): return bp(rng.standard_normal(int(SR * d)), 6000, 14000) * env(d, 0.001, 70)
def tom(m, d=0.35): t = T(d); f = hz(m) * (1 + 0.5 * np.exp(-t * 20)); return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(d, 0.002, 10)
def pad(ms, d): t = T(d); x = sum(np.sin(2 * np.pi * hz(m) * t + i) + 0.3 * np.sin(2 * np.pi * hz(m) * 1.003 * t) for i, m in enumerate(ms)); a = np.minimum(1, t / 0.4) * np.minimum(1, (d - t) / 0.4); return x * a / len(ms)
def saw(m, d): t = T(d); f = hz(m); x = 2 * ((f * t) % 1) - 1; return bp(x, 40, 1200) * np.minimum(1, t / 0.08) * np.minimum(1, (d - t) / 0.08)
# A 0-20.5 light street-organ oompah in C / F / G
prog = [(48, [64, 67, 72]), (53, [65, 69, 72]), (55, [62, 67, 71]), (48, [64, 67, 72])]
mel = [76, 79, 77, 76, 74, 76, 72, None, 74, 77, 76, 74, 72, 74, 71, None]
b = 0; t = 0.0
while t < 20.5:
    root, ch = prog[(b // 4) % 4]
    if b % 2 == 0: add(mus, tuba(root - 12 + (7 if b % 4 == 2 else 0)), t, 0.5)
    else:
        for m in ch: add(mus, pluck(m), t, 0.16)
    m = mel[b % 16]
    if m and b >= 4: add(mus, bell(m), t, 0.13)
    add(mus, hat(), t + 0.25, 0.05); b += 1; t += BEAT
# B 20.5-26.1 sneak: staccato walking pizzicato, minor
walk = [45, 47, 48, 50, 51, 50, 48, 47]
t = 20.5; k = 0
while t < 26.1:
    add(mus, pluck(walk[k % 8] - 12, 0.18), t, 0.45); add(mus, pluck(walk[k % 8], 0.12), t + 0.25, 0.12); add(mus, hat(0.03), t + 0.25, 0.05); k += 1; t += BEAT
# C 26.1-34.77 tension drums + drone
t = 26.1; k = 0
while t < 34.77:
    add(mus, kick(), t, 0.55); add(mus, hat(), t + 0.25, 0.06)
    if k % 4 == 3: add(mus, tom(45), t + 0.25, 0.3); add(mus, tom(41), t + 0.375, 0.3)
    k += 1; t += BEAT
add(mus, saw(33, 8.7), 26.1, 0.16); add(mus, saw(40, 8.7), 26.1, 0.1)
# D 34.77-44.15 somber pads + soft half-time pulse
for i, ms in enumerate([[57, 60, 64], [53, 57, 60], [55, 59, 62], [52, 56, 59], [57, 60, 64]]):
    add(mus, pad(ms, 2.0), 34.77 + i * 1.9, 0.22)
t = 34.77
while t < 44.0: add(mus, kick(0.25), t, 0.25); t += 1.0
add(mus, saw(57, 1.0) * np.linspace(0, 1, int(SR)) ** 2, 42.4, 0.25)  # riser into "spark"
# E 44.15-52.92 warm light: major plucks + soft bass (after the dead stop)
prog2 = [(53, [65, 69, 72]), (48, [64, 67, 72]), (55, [62, 67, 71]), (53, [65, 69, 72])]
t = 44.5; b = 0
while t < 52.9:
    root, ch = prog2[(b // 4) % 4]
    if b % 2 == 0: add(mus, tuba(root - 12, 0.4), t, 0.4)
    for j, m in enumerate(ch): add(mus, pluck(m + 12, 0.3), t + j * 0.08, 0.08)
    if b % 4 == 0: add(mus, bell(ch[2] + 12), t, 0.1)
    b += 1; t += BEAT
# F 52.92-57 soft tension -> final hit on "cut"
t = 52.92
while t < 55.9: add(mus, kick(0.2), t, 0.3); add(mus, pluck(45, 0.2), t + 0.25, 0.2); t += BEAT
add(mus, saw(45, 3.0), 52.92, 0.08)
hit = kick(0.8) * 1.2 + bp(rng.standard_normal(int(SR * 0.8)), 200, 4000) * env(0.8, 0.001, 9) * 0.4; add(mus, hit, 55.92, 0.6)
add(mus, pad([45, 52, 57], 1.1), 55.92, 0.18)
# dead stops (silence) on 3 key moments
for a, d in [(23.5, 0.55), (33.74, 0.5), (44.15, 0.35)]:
    i, j = int(a * SR), int((a + d) * SR); mus[i:j] = 0; f = int(0.01 * SR); mus[i - f:i] *= np.linspace(1, 0, f)

# ---------------- ambience beds ----------------
amb = np.zeros(N)
def water(d):
    x = bp(rng.standard_normal(int(SR * d)), 150, 900); m = 0.6 + 0.4 * np.sin(2 * np.pi * 0.35 * T(d)) * np.sin(2 * np.pi * 0.11 * T(d) + 1); y = x * m
    for k in range(int(d * 2.5)):
        tt = rng.uniform(0, d - 0.1); add(y, np.sin(2 * np.pi * (900 + rng.uniform(0, 700)) * T(0.06)) * env(0.06, 0.001, 60) * 2, tt)
    return y
def crowd(d, k=1.0):
    x = sum(bp(rng.standard_normal(int(SR * d)), 250 + 180 * i, 700 + 300 * i) * (0.6 + 0.4 * np.sin(2 * np.pi * (2.1 + i * 0.7) * T(d) + i)) for i in range(4)); return x * k
def birds(d):
    y = np.zeros(int(SR * d))
    for k in range(int(d * 3)):
        tt = rng.uniform(0, d - 0.2); f0 = rng.uniform(2500, 4200); t = T(0.12); add(y, np.sin(2 * np.pi * np.cumsum(f0 + 1500 * np.sin(2 * np.pi * 18 * t)) / SR) * env(0.12, 0.005, 25), tt)
    return y
def wind(d): return bp(rng.standard_normal(int(SR * d)), 80, 500) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.2 * T(d)))
def place(x, a, b, g):
    i, j = int(a * SR), int(b * SR); L = j - i; y = x[:L].copy(); f = int(0.25 * SR); y[:f] *= np.linspace(0, 1, f); y[-f:] *= np.linspace(1, 0, f); amb[i:i + len(y)] += y * g
place(water(26.3) + crowd(26.3, 0.5), 0.0, 26.3, 0.5)
place(crowd(5.6, 1.6), 26.0, 31.6, 0.6)
place(wind(3.6) + crowd(3.6, 0.6), 31.3, 34.9, 0.45)
place(water(3.6) + wind(3.6), 34.7, 38.3, 0.45)
place(crowd(6.1, 0.8) + wind(6.1), 38.1, 44.2, 0.4)
place(water(5.3) + crowd(5.3, 0.5), 44.1, 49.4, 0.5)
place(water(3.8) + birds(3.8), 49.2, 53.0, 0.45)
place(water(4.2) * 0.6 + wind(4.2), 52.8, 57.0, 0.4)

# ---------------- SFX events ----------------
lib = {n: rd(f"{SFXD}/{n}.wav") for n in ["whoosh", "swing", "pop", "tick", "impact", "glass", "ding", "sparkle", "slash", "click", "riser", "stamp", "roll", "sand"]}
def plop(): t = T(0.25); f = 900 * np.exp(-t * 14) + 180; return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(0.25, 0.002, 16)
def splash(): return bp(rng.standard_normal(int(SR * 0.7)), 400, 7000) * env(0.7, 0.004, 6)
def cheer(d=1.6): x = crowd(d, 1.0) + bp(rng.standard_normal(int(SR * d)), 900, 3500) * 0.5; return x * np.sin(np.pi * np.minimum(1, T(d) / d)) ** 0.6
def crack():
    y = kick(0.4) * 0.8; n = bp(rng.standard_normal(int(SR * 0.25)), 1200, 9000) * env(0.25, 0.0005, 35); y[:len(n)] += n; return y
def rewind(): t = T(0.6); f = 1800 * np.exp(-t * 3) + 200; return (np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.3 + bp(rng.standard_normal(len(t)), 500, 5000) * 0.6) * np.sin(np.pi * t / 0.6)
lib.update(plop=plop(), splash=splash(), cheer=cheer(), crack=crack(), rewind=rewind())
cuts = json.load(open(CUTS)); ev = []
for c in cuts["cuts"]: ev.append((c - 2 / 30, "whoosh" if c in cuts["stages"] else "swing", -3 if c in cuts["stages"] else -5))
for p in cuts["pops"]: ev.append((p + 0.02, "pop" if p < 1 else "tick" if int(p * 10) % 2 else "pop", -6))
ev += [(0.0, "whoosh", -4), (0.05, "sand", -8), (1.2, "plop", -8),                      # eel swings at the lens, drip
       (5.3, "ding", -10), (9.73, "sparkle", -6),                                     # date, slick sheen, rope creak
       (13.5, "swing", -4), (14.45, "stamp", -6), (14.5, "plop", -6), (15.94, "cheer", -2),  # jump, slip, landing, roar
       (17.35, "splash", -2), (17.4, "plop", -4),                # second jumper misses, splashes
       (19.93, "stamp", -4), (22.98, "sparkle", -3),            # BANNED, shoves, knife glint
       (23.5, "slash", 0), (25.30, "splash", 0), (25.32, "plop", -2),
       (27.47, "impact", 0), (27.5, "cheer", 0),
       (29.1, "impact", -6), (29.42, "glass", -8), (29.72, "impact", -6), (30.32, "impact", -5), (30.6, "cheer", -4),
       (33.1, "click", -6), (33.74, "crack", 0),
       (34.82, "ding", -12), (36.4, "tick", -8), (37.0, "tick", -8), (37.6, "tick", -8),
       (41.1, "stamp", -6), (43.4, "impact", -4),
       (44.12, "rewind", 0), (47.95, "swing", -5), (48.25, "ding", -6), (48.5, "cheer", -2),
       (51.3, "click", -6), (51.9, "click", -6),
       (54.11, "sparkle", -6), (55.6, "riser", -6), (55.92, "slash", 0)]
sfx = np.zeros(N)
for t, n, db in ev: add(sfx, lib[n] / (np.abs(lib[n]).max() + 1e-9) * 0.7, max(0, t), 10 ** (db / 20))
ev.sort()
json.dump([{"t": round(t, 3), "sfx": n, "db": db} for t, n, db in ev], open(f"{OUT}/sfx-events.json", "w"), indent=0)
wr(f"{OUT}/music011.wav", mus / np.abs(mus).max() * 0.8); wr(f"{OUT}/amb011.wav", amb / np.abs(amb).max() * 0.8); wr(f"{OUT}/sfx011.wav", sfx / np.abs(sfx).max() * 0.8)
n_all = len(ev); first3 = sum(1 for t, _, _ in ev if t < 3); last10 = sum(1 for t, _, _ in ev if t >= DUR - 10)
print(f"sfx events {n_all} ({n_all / DUR * 60:.1f}/min), first 3 s: {first3}, last 10 s: {last10}")
