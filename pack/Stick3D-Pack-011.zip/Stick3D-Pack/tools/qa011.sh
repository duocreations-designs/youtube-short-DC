#!/usr/bin/env bash
# qa011.sh master.mp4 outdir : streams, blackdetect, freezedetect, ebur128, 12-frame contact sheet, pop-text frames (9 after start, 3 before end)
M="$1"; O="$2"; mkdir -p "$O/pop" "$O/sheet"
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate,sample_rate,bit_rate:format=duration,size -of compact "$M" > "$O/streams.txt"
ffmpeg -nostats -i "$M" -vf "blackdetect=d=0.03:pix_th=0.06,freezedetect=n=0.003:d=1.5" -an -f null - 2> "$O/detect.log"; grep -E "black_start|freeze_start" "$O/detect.log" > "$O/detect_hits.txt"
ffmpeg -nostats -i "$M" -af ebur128=peak=true -f null - 2>&1 | tail -14 > "$O/loudness.txt"
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$M")
for i in $(seq 0 11); do T=$(python3 -c "print(round(($i+0.5)*$D/12,2))"); ffmpeg -v error -y -ss $T -i "$M" -frames:v 1 -vf scale=360:640 "$O/sheet/s$(printf %02d $i).png"; done
python3 - "$O" <<'P'
import sys,glob; from PIL import Image
o=sys.argv[1]; fs=sorted(glob.glob(o+"/sheet/s*.png")); ims=[Image.open(f) for f in fs]; w,h=ims[0].size; c=Image.new("RGB",(w*6,h*2))
for i,im in enumerate(ims): c.paste(im,((i%6)*w,(i//6)*h))
c.save(o+"/contact12.png")
P
