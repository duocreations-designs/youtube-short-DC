# sheet.py dir out.png cols -> labelled contact sheet of f*.png
import sys, glob, os
from PIL import Image, ImageDraw
d, out, cols = sys.argv[1], sys.argv[2], int(sys.argv[3])
fs = sorted(glob.glob(os.path.join(d, "f*.png"))); ims = [Image.open(f) for f in fs]; w, h = ims[0].size; w2, h2 = w // 2, h // 2
rows = (len(ims) + cols - 1) // cols; c = Image.new("RGB", (cols * w2, rows * h2), "black"); dr = ImageDraw.Draw(c)
for i, (f, im) in enumerate(zip(fs, ims)):
    x, y = (i % cols) * w2, (i // cols) * h2; c.paste(im.resize((w2, h2)), (x, y))
    # mark the top text band (8-28%) and caption line
    dr.rectangle([x, y + int(h2 * 0.08), x + w2 - 1, y + int(h2 * 0.28)], outline=(255, 0, 255))
    dr.text((x + 4, y + 4), os.path.basename(f)[1:5] + f" {int(os.path.basename(f)[1:5])/30:.1f}s", fill=(255, 255, 0))
c.save(out)
