# Odd Truth Toons rules, as applied in this pack (cloud route, first used for 011 Eel)
The full rules live in the user's vault `yt shorts` (03 Productie/Regels brug beweging thumbnail en uniek.md). This file holds the numbers a cloud session needs when the vault is not reachable. Talk Dutch, videos English, no emoji.

## Topic
- Themes: money, crime and spying, record and extreme, secret and hidden. Unknown to most viewers.
- Unique test: assume videos exist. Search at least 4 phrasings, also in the local language. Pick an angle no found video uses. Score 8 of 10 or more.
- No format fatigue: never 2 Shorts in a row with the same form.
- Real stories: every fact 2 sources. Invented stories: the mechanism must check out with 2 sources.

## Script
55 to 62 s spoken, 16 to 18 sentences, about 200 words. Sentence 1: odd detail or contradiction, no outcome. A "But" (or other contrast) starts by 7.0 s (frame 210). A twist every 3 sentences (But, So, Then). Explanation near 60% ("You see"). Every person, place or group gets a name the viewer can follow.

## Voice
Harrison `573e5163-59b3-4926-aab1-951ef2985f81`, Higgsfield `elevenlabs_v4`, stability 0.25, one dialogue line per sentence with emotion tags. Pauses max 0.25 s (one 0.4 s before a twist). Tempo 3.5 to 3.6 words per second, first to last word, sentence 1 not sped up.
Cloud route: download from d8j0ntlcm91z4.cloudfront.net (allowed host), `tools/voice/align.py` for timings, pause trim + `rubberband` tempo (`python3 -I tools/voice/edit_voice.py raw.wav raw_words.json voice.wav 3.55`).

## Picture
- Frame 0 moves. First 1.5 s: 2 motions at once and 3 sounds; something comes at the lens in the first 0.5 s.
- New visual moment every 2 to 3 s. Cuts 15 to 35 per minute, first cut by 2.7 s, fast camera moves 8 to 14 per minute, close-ups 17.5 to 42.6% of seconds.
- Crossfades only between stages (sets); inside a stage hard cuts (`Shots` in videos/Eel011.tsx).
- Faces and key objects stay out of the top text band (8 to 28% of the height).

## On-screen text
- Hook text 3 to 7 words from frame 0 to about 2 s, not the words of sentence 1.
- A pop text at every number, name and new place, on the voice word. Top band from y 100 (of 1280). Shrink to 88% width. Yellow #FFE830 numbers and times, green #7AFF80 money gained, red #FF5C4A loss or danger, white names. Thick dark stroke and shadow.
- A pop ends 1 frame after a hard cut and 6 frames before a crossfade, and stays at least 0.4 s.
- Word captions always on: 1 or 2 words, Archivo Black, white with black stroke, centre at y 900 of 1280. Nothing at y 1133 to 1200 (YouTube's own text).

## Sound
Own music in code at 120 bpm with a style per part and dead stops on 2 or 3 key moments. An ambience bed per set. A swish on every cut, whoosh on stage changes, tink or pop on every text, plop when something drops. At least 5 sounds in the first 3 s and 12 in the last 10 s, 53 to 105 sounds per minute. Music and effects 16 to 21 dB under the voice. -14 LUFS, true peak at most -1 dBTP, LRA 1.7 to 3.2 LU. Scripts: 02-videos/011-eel/audio011.py and mix011.py.

## Master and checks
1440x2560 (render the 720x1280 composition with `--scale=2`), 30 fps, x264 CRF 16, BT.709 tags, AAC 256 kbps 48 kHz, faststart. Render in 4 parts, at most 2 at once (`out/render_parts011.sh`, each part has its own software-GPU process, about 3.4 s per frame in total on 4 CPU cores).
Before delivery: But frame <= 210, tempo 3.5 to 3.6, every pop text viewed, 12-frame contact sheet, part seams, blackdetect and freezedetect clean, ebur128 -14 LUFS and true peak <= -1 (`tools/qa011.sh`).

## Delivery
Thumbnails: `node engine/scripts/thumbs.mjs <engineDir> Eel011 <outDir> 1.5 jobs.json` renders clean stills (no captions) with a big top text per job.
Master + title (choice question, no emoji or hashtag) + description (hook line, blank, question, blank, 3 to 5 hashtags) + 6 to 8 thumbnail candidates with `kies_0NN.png` + Short note in the vault format. Claude never posts or schedules without a request per Short.
